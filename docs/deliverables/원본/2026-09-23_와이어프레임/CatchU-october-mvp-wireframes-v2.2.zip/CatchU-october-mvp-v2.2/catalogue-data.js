window.wireframeCatalogue = [
  {
    "id": "W01",
    "name": "구직자 로그인",
    "owner": "A · 팀원 2",
    "group": "회원·홈",
    "states": {
      "normal": "기본",
      "cancel": "로그인 취소",
      "error": "로그인 실패",
      "expired": "세션 만료",
      "unknown": "로그인 응답 확인 불가"
    }
  },
  {
    "id": "W01-R",
    "name": "로그인 직후 표시 이름 조회",
    "owner": "A · 팀원 2",
    "group": "회원·홈",
    "states": {
      "loading": "조회 중",
      "error": "조회 실패",
      "missing": "이름 미저장",
      "saved": "이름 저장됨",
      "expired": "조회 중 세션 만료",
      "logoutError": "로그아웃 실패"
    }
  },
  {
    "id": "W02",
    "name": "기본 프로필",
    "owner": "A · 팀원 2",
    "group": "회원·홈",
    "states": {
      "normal": "최초 입력",
      "edit": "프로필 수정",
      "saving": "저장 중",
      "error": "저장 실패",
      "unknown": "저장 여부 불명",
      "loadError": "조회 실패",
      "emptyName": "표시 이름 미입력",
      "unsaved": "수정 중 · 미저장 변경",
      "logoutError": "로그아웃 실패 · 입력 유지"
    }
  },
  {
    "id": "W02-P",
    "name": "프로필 모달·상세 보기",
    "owner": "A · 팀원 2",
    "group": "회원·홈",
    "states": {
      "normal": "상세 보기",
      "modal": "프로필 모달",
      "loading": "조회 중",
      "error": "조회 실패"
    }
  },
  {
    "id": "W02-G",
    "name": "프로필 GitHub 연결",
    "owner": "A · 팀원 2",
    "group": "회원·홈",
    "states": {
      "normal": "미연동",
      "connected": "연동됨",
      "loading": "연동 중",
      "cancel": "연동 취소",
      "error": "연동 실패",
      "unknown": "연동 상태 확인 불가",
      "checking": "연결 상태 조회 중",
      "reauth": "GitHub 권한 만료",
      "expired": "CatchU 세션 만료"
    }
  },
  {
    "id": "H-01",
    "name": "첫 방문·재방문 홈",
    "owner": "D · 팀원 3",
    "group": "회원·홈",
    "states": {
      "normal": "비로그인",
      "unlinked": "로그인 · 미연동",
      "linked": "연동 · 저장소 선택 전",
      "ready": "저장소 연결 후",
      "error": "연결 상태 조회 실패",
      "loading": "연결 상태 조회 중",
      "authLoading": "로그인 여부 확인 중",
      "authError": "로그인 여부 조회 실패",
      "expired": "로그인 세션 만료"
    }
  },
  {
    "id": "W03",
    "name": "본인 자산·분석 이력",
    "owner": "B · 팀원 4",
    "group": "자산·분석",
    "states": {
      "normal": "연결된 예시",
      "empty": "빈 Catch·이력",
      "history": "분석 이력 비교",
      "loading": "목록 조회 중",
      "error": "목록 조회 실패",
      "unlinked": "GitHub 미연동",
      "denied": "본인 접근 불가",
      "resultError": "이력의 결과 수 조회 실패"
    }
  },
  {
    "id": "A-01",
    "name": "저장소 선택·동의",
    "owner": "D · 팀원 3 / A·E · 팀원 2",
    "group": "자산·분석",
    "states": {
      "normal": "선택 전",
      "selected": "저장소 선택·동의 안내",
      "empty": "선정 저장소 0개",
      "loading": "목록 조회 중",
      "error": "목록 조회 실패",
      "denied": "선정·접근 조건 미충족",
      "sending": "요청 전송 중",
      "accepted": "요청 접수",
      "unknown": "접수 여부 불명",
      "duplicate": "같은 저장소 분석 진행 중",
      "reanalysis": "과거 분석 대상 재선택",
      "expired": "요청 전 세션 만료"
    }
  },
  {
    "id": "A-02",
    "name": "분석 상태 확인",
    "owner": "D · 팀원 3 / E · 팀원 2",
    "group": "자산·분석",
    "states": {
      "accepted": "접수 확인",
      "queued": "분석 대기",
      "running": "분석 진행",
      "preparing": "결과 준비 중",
      "complete": "분석 완료 · 결과 있음",
      "zero": "정상 완료 · 후보 0건",
      "insufficient": "정상 완료 · 근거 부족/기준 미달",
      "partial": "일부 분석 실패 · 유효 결과 있음",
      "draftFail": "설명 초안 생성 실패 · Catch 있음",
      "collectionFail": "수집 실패",
      "generationFail": "분석 처리 실패 · 판단 불가",
      "applicationFail": "결과 반영 확인 불가",
      "error": "상태 조회 실패",
      "unknown": "접수 여부 불명",
      "expired": "세션 만료",
      "recovering": "결과 반영 복구 중",
      "partialPending": "일부 실패 · 열람 준비 미확인",
      "missing": "분석 없음 · 본인 분석 아님",
      "loading": "현재 상태 조회 중"
    }
  },
  {
    "id": "A-03",
    "name": "실패·명시 재요청",
    "owner": "D · 팀원 3 / E·F 연결",
    "group": "자산·분석",
    "states": {
      "normal": "분석 실패 확인",
      "partial": "일부 실패 · 유효 결과 있음",
      "error": "상태 조회 실패",
      "retry": "재요청 진입 · 정책 미결",
      "sending": "재요청 전송 중 예시",
      "accepted": "재요청 접수 예시",
      "rejected": "재요청 거절 예시",
      "unknown": "접수 여부 불명",
      "allowed": "재요청 조건 충족 가정",
      "partialPending": "일부 실패 · 제공 가능 결과 미확인",
      "loading": "현재 상태 조회 중",
      "missing": "분석 없음 · 본인 분석 아님",
      "currentRunning": "이미 다시 진행 중",
      "currentComplete": "이미 완료 상태",
      "expired": "세션 만료"
    }
  },
  {
    "id": "W03-R",
    "name": "본인 결과 목록",
    "owner": "B · 팀원 4 / D 연결",
    "group": "Catch 확인·공개",
    "states": {
      "normal": "연결된 결과",
      "single": "Catch 1개",
      "zero": "정상 0건",
      "partial": "부분 실패 결과",
      "noDraft": "초안 없는 Catch 포함",
      "loading": "결과 조회 중",
      "error": "결과 조회 실패",
      "denied": "본인 접근 불가",
      "missing": "분석 대상·진입 출처 확인 불가"
    }
  },
  {
    "id": "W04",
    "name": "본인 근거 확인·Catch 상세",
    "owner": "B · 팀원 4 / F 의미 연결",
    "group": "Catch 확인·공개",
    "states": {
      "normal": "연결된 Catch",
      "unconfirmed": "확인 전 · 미공개",
      "confirmed": "확인 완료 · 미공개",
      "noDraft": "초안 없음 · 확인 전",
      "public": "확인 완료 · 공개",
      "hidden": "공개 후 숨김",
      "mismatch": "불일치 표시 · 미공개",
      "saveError": "확인 저장 실패",
      "error": "상세 조회 실패",
      "denied": "본인 접근 불가",
      "protected": "원본 비공개 확인",
      "sourceError": "원본 접근 일시 실패",
      "saving": "확인 저장 중",
      "saveUnknown": "확인 저장 여부 불명",
      "hideError": "숨김 저장 실패",
      "mismatchError": "불일치 저장 실패"
    }
  },
  {
    "id": "W05",
    "name": "확인 완료 후 공개 선택",
    "owner": "B · 팀원 4 / C 연결",
    "group": "Catch 확인·공개",
    "states": {
      "normal": "확인 완료 · 미공개",
      "noDraft": "초안 없는 Catch 공개 선택",
      "saving": "공개 저장 중",
      "error": "공개 저장 실패",
      "public": "공개 완료",
      "afterLink": "발행 후 새 공개 · 정책 미결",
      "unknown": "공개 저장 여부 불명"
    }
  },
  {
    "id": "L01",
    "name": "발행자 링크 발행",
    "owner": "C · 팀원 3",
    "group": "링크·수신자",
    "states": {
      "normal": "발행 준비",
      "empty": "공개 Catch 0개",
      "loading": "공개 자료 조회 중",
      "error": "공개 자료 조회 실패",
      "duplicate": "유효 제목 중복",
      "limit": "유효 링크 5개",
      "password": "선택 비밀번호 사용",
      "sending": "발행 중",
      "failed": "발행 실패",
      "unknown": "발행 여부 불명"
    }
  },
  {
    "id": "L02",
    "name": "링크 발행 결과",
    "owner": "C · 팀원 3",
    "group": "링크·수신자",
    "states": {
      "normal": "발행 완료",
      "password": "비밀번호 설정 링크",
      "copyError": "복사 실패"
    }
  },
  {
    "id": "L03",
    "name": "발행자 링크 관리",
    "owner": "C · 팀원 3",
    "group": "링크·수신자",
    "states": {
      "normal": "연결된 링크",
      "examples": "유효·중단·만료 비교",
      "empty": "발행 링크 없음",
      "loading": "목록 조회 중",
      "error": "목록 조회 실패",
      "stopping": "중단 요청 중",
      "stopError": "중단 실패",
      "stopUnknown": "중단 여부 불명",
      "confirm": "중단 전 영향 확인"
    }
  },
  {
    "id": "V01",
    "name": "비로그인 수신자 · 비밀번호",
    "owner": "C · 팀원 3",
    "group": "링크·수신자",
    "states": {
      "normal": "비밀번호 입력",
      "wrong": "비밀번호 불일치",
      "loading": "비밀번호 확인 중",
      "error": "비밀번호 확인 실패",
      "blocked": "중단·만료 우선 거부"
    }
  },
  {
    "id": "V02",
    "name": "비로그인 수신자 · 자료 탭·AI 요약",
    "owner": "C · 팀원 3 / A·B 연결",
    "group": "링크·수신자",
    "states": {
      "normal": "현재 허용된 자료",
      "empty": "공개 자료 0개",
      "error": "자료 조회 실패",
      "denied": "없는 링크 · 접근 거부",
      "stopped": "중단 링크 · 접근 거부",
      "expired": "만료 링크 · 접근 거부",
      "password": "비밀번호 필요",
      "loading": "최초 자료 조회 중",
      "followupError": "열람 중 후속 조회 실패",
      "jdPreset": "JD 프리셋 기준 요약",
      "jdCustom": "직접 입력한 JD 기준 요약",
      "portfolio": "포트폴리오 · 준비 중",
      "coverLetter": "자기소개서 · 준비 중",
      "resume": "이력서 · 준비 중",
      "rag": "RAG 질문 입력",
      "ragAnswer": "RAG 답변·근거 예시"
    }
  },
  {
    "id": "V03",
    "name": "비로그인 수신자 · Catch·근거",
    "owner": "C · 팀원 3 / B 연결",
    "group": "링크·수신자",
    "states": {
      "normal": "현재 허용된 Catch",
      "noDraft": "초안 없는 공개 Catch",
      "hidden": "숨김 Catch 직접 접근",
      "missing": "없는 Catch 직접 접근",
      "protected": "원본 비공개 보호",
      "error": "자료 조회 실패",
      "sourceError": "원본 접근 일시 실패",
      "stopped": "중단 링크 우선 거부",
      "expired": "만료 링크 우선 거부",
      "password": "비밀번호 인증 전",
      "loading": "상세 조회 중",
      "followupError": "열람 중 후속 조회 실패"
    }
  }
];