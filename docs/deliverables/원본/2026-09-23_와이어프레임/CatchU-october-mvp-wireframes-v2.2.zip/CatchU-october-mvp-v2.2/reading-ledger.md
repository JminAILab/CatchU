# 읽기 범위와 남은 한계

2026-09-23. 이전 결과물을 만들 때 저장소 전 파일을 읽은 것은 아닙니다. 이번에도 **모든 파일을 전문 정독했다고 주장하지 않습니다.** 경로 전체 인벤토리를 먼저 확인하고, 현행 제품 화면에 직접 연결되는 요구·범위·도메인·화면 문서를 우선 대조했습니다. 사용자의 “파일 전체를 읽어 달라”는 요청 중 전 파일 전문 정독은 완료하지 않았으며, 아래에 실제 열람 범위를 남깁니다.

저장소의 web/api/worker는 기준 판본에서 README와 자리표시자 수준입니다. 실제 제품 코드에서 확인한 화면·API·운영 데이터라고 제시하지 않습니다. 팀장님이 전달한 index.html, styles.css, app.js, README.md는 4개 모두 전문을 읽고 비교했습니다. 그 코드와 합성 데이터를 상세 화면 기반으로 사용했습니다.

## 확인 방식

- dev와 관련 PR 판본의 경로 합집합을 조사했습니다. 파일 내용 확인과 경로 확인을 구분합니다.
- PR #68·#80 및 해당 요구·도메인 문서, 최신 회원(PR #79), 홈·분석(PR #71), 공유 링크(PR #57) 판본을 고정했습니다.
- 초기 입력의 대표 구성·G 운영 항목을 현행 첫 MVP 범위로 그대로 옮기지 않았습니다. 범위 문서의 이후 결정을 우선 적용했습니다.
- 문서를 파일로 수집하거나 해시를 계산한 것만으로 전문을 읽었다고 집계하지 않았습니다. 긴 문서의 관련 절만 읽은 경우를 명시합니다.

## 제외 사유

- `docs/ai-dlc-input/`: AGENTS.md가 현행 기준으로 읽지 말도록 지정한 초기 스냅샷입니다.
- 과거 실험 원자료·원문 발췌·생성 응답·저장 결과와 비밀값: 화면 자료로 읽거나 복원·복사하지 않았습니다. 정책/수용 검토의 문서상 결정 의미만 참조했습니다.
- AI-DLC 도구·스킬·하네스와 감사 로그: 제품 데이터·화면 요구사항이 아니므로 모두 정독하는 범위에 넣지 않았습니다. 공식 기록을 바꾸지 않았습니다.
- 12월 페르소나/제안·과거 실험 설명은 현행 MVP 결정과 구분합니다. 미채택 자료의 내용에서 신규 기능을 만들지 않았습니다.

## 문서별 실제 열람

전체 경로와 분류는 [repository-inventory.json](repository-inventory.json), 판본·해시는 [source-inventory.json](source-inventory.json)에 있습니다.

| 자료 | 열람 상태 | 판본 |
|---|---|---|
| [README.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/README.md) | 전문 열람 | `8866a682` |
| [aidlc/spaces/default/intents/260909-catchu-definition-review/inception/requirements-analysis/requirements.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260909-catchu-definition-review/inception/requirements-analysis/requirements.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/approval-handoff/decision-log.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/approval-handoff/decision-log.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/approval-handoff/initiative-brief.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/approval-handoff/initiative-brief.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/intent-capture/intent-statement.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/intent-capture/intent-statement.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/rough-mockups/user-flow.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/rough-mockups/user-flow.md) | 전문 열람 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/rough-mockups/wireframes.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/rough-mockups/wireframes.md) | 전문 열람 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/scope-definition/intent-backlog.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/scope-definition/intent-backlog.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/scope-definition/scope-document.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/scope-definition/scope-document.md) | 전문 열람 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/components.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/components.md) | 전문 열람 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/decisions.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/decisions.md) | 전문 열람 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/domain-design-questions.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/domain-design-questions.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `e05ca63e` |
| [aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/requirements-analysis/requirements.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/requirements-analysis/requirements.md) | 전문 열람 | `e05ca63e` |
| [api/.gitignore](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/api/.gitignore) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [api/README.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/api/README.md) | 전문 열람 | `8866a682` |
| [docs/CatchU_KPI_성공기준_v4_1.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/CatchU_KPI_%EC%84%B1%EA%B3%B5%EA%B8%B0%EC%A4%80_v4_1.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/CatchU_그라운드룰_2026-08-04.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/CatchU_%EA%B7%B8%EB%9D%BC%EC%9A%B4%EB%93%9C%EB%A3%B0_2026-08-04.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/CatchU_레포_컨벤션.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/CatchU_%EB%A0%88%ED%8F%AC_%EC%BB%A8%EB%B2%A4%EC%85%98.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/CatchU_작업관리.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/CatchU_%EC%9E%91%EC%97%85%EA%B4%80%EB%A6%AC.md) | 전문 열람 | `8866a682` |
| [docs/P1_설계노트_v2_0.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/P1_%EC%84%A4%EA%B3%84%EB%85%B8%ED%8A%B8_v2_0.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/P2_설계노트_v2_0.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/P2_%EC%84%A4%EA%B3%84%EB%85%B8%ED%8A%B8_v2_0.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/P3_설계노트_v2_0.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/P3_%EC%84%A4%EA%B3%84%EB%85%B8%ED%8A%B8_v2_0.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/P4_설계노트_v2_0.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/P4_%EC%84%A4%EA%B3%84%EB%85%B8%ED%8A%B8_v2_0.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/README.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/README.md) | 전문 열람 | `8866a682` |
| [docs/ai-dlc-input-december/CatchU_12월_범위_보완.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-december/CatchU_12%EC%9B%94_%EB%B2%94%EC%9C%84_%EB%B3%B4%EC%99%84.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/ai-dlc-input-december/README.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-december/README.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/ai-dlc-input-mvp/2026-09-14_followup.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-14_followup.md) | 전문 열람 | `8866a682` |
| [docs/ai-dlc-input-mvp/2026-09-16_feasibility-resume.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-16_feasibility-resume.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/ai-dlc-input-mvp/2026-09-16_meeting-decisions.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-16_meeting-decisions.md) | 전문 열람 | `8866a682` |
| [docs/ai-dlc-input-mvp/2026-09-17_C02-C01_결과보고_양식.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-17_C02-C01_%EA%B2%B0%EA%B3%BC%EB%B3%B4%EA%B3%A0_%EC%96%91%EC%8B%9D.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/ai-dlc-input-mvp/2026-09-17_C02-C01_수용검토_변경안.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/docs/ai-dlc-input-mvp/2026-09-17_C02-C01_%EC%88%98%EC%9A%A9%EA%B2%80%ED%86%A0_%EB%B3%80%EA%B2%BD%EC%95%88.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `e05ca63e` |
| [docs/ai-dlc-input-mvp/2026-09-17_C02-C01_재검증_인계.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-17_C02-C01_%EC%9E%AC%EA%B2%80%EC%A6%9D_%EC%9D%B8%EA%B3%84.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/ai-dlc-input-mvp/2026-09-17_Claude_Code_시작_프롬프트.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-17_Claude_Code_%EC%8B%9C%EC%9E%91_%ED%94%84%EB%A1%AC%ED%94%84%ED%8A%B8.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/ai-dlc-input-mvp/2026-09-17_Rough-Mockups_팀별_첫작업_안내.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-17_Rough-Mockups_%ED%8C%80%EB%B3%84_%EC%B2%AB%EC%9E%91%EC%97%85_%EC%95%88%EB%82%B4.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/ai-dlc-input-mvp/CatchU_mvp_input.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/CatchU_mvp_input.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/ai-dlc-input-mvp/CatchU_공유링크_정보_판단조건_초안.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%EC%A0%95%EB%B3%B4_%ED%8C%90%EB%8B%A8%EC%A1%B0%EA%B1%B4_%EC%B4%88%EC%95%88.md) | 전문 열람 | `8866a682` |
| [docs/ai-dlc-input-mvp/CatchU_공유링크_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/12b30d8939f45ed078c6ea29cf7dc68fc0f92ed4/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) | 전문 열람 | `12b30d89` |
| [docs/ai-dlc-input-mvp/CatchU_공통_아키텍처_검토초안.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%ED%86%B5_%EC%95%84%ED%82%A4%ED%85%8D%EC%B2%98_%EA%B2%80%ED%86%A0%EC%B4%88%EC%95%88.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/ai-dlc-input-mvp/CatchU_분석실패_재요청_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/eb645ab46c568f9df768e80bd4eed396c0a5c5c2/docs/ai-dlc-input-mvp/CatchU_%EB%B6%84%EC%84%9D%EC%8B%A4%ED%8C%A8_%EC%9E%AC%EC%9A%94%EC%B2%AD_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) | 전문 열람 | `eb645ab4` |
| [docs/ai-dlc-input-mvp/CatchU_분석진행_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/eb645ab46c568f9df768e80bd4eed396c0a5c5c2/docs/ai-dlc-input-mvp/CatchU_%EB%B6%84%EC%84%9D%EC%A7%84%ED%96%89_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) | 전문 열람 | `eb645ab4` |
| [docs/ai-dlc-input-mvp/CatchU_서비스홈_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/eb645ab46c568f9df768e80bd4eed396c0a5c5c2/docs/ai-dlc-input-mvp/CatchU_%EC%84%9C%EB%B9%84%EC%8A%A4%ED%99%88_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) | 전문 열람 | `eb645ab4` |
| [docs/ai-dlc-input-mvp/CatchU_저장소선택_분석동의_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/CatchU_%EC%A0%80%EC%9E%A5%EC%86%8C%EC%84%A0%ED%83%9D_%EB%B6%84%EC%84%9D%EB%8F%99%EC%9D%98_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) | 전문 열람 | `8866a682` |
| [docs/ai-dlc-input-mvp/CatchU_회원자산_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/a9bbc50fa2b8b3dae36649f7b9dd18175ebd25c2/docs/ai-dlc-input-mvp/CatchU_%ED%9A%8C%EC%9B%90%EC%9E%90%EC%82%B0_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) | 전문 열람 | `a9bbc50f` |
| [docs/ai-dlc-input-mvp/README.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/README.md) | 전문 열람 | `8866a682` |
| [docs/web-mock-demo/README.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/web-mock-demo/README.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/web-mock-demo/code-generation-plan.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/web-mock-demo/code-generation-plan.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/web-mock-demo/provenance.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/web-mock-demo/provenance.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/web-mock-demo/requirements-reference.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/web-mock-demo/requirements-reference.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/web-mock-demo/unit-test-instructions.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/web-mock-demo/unit-test-instructions.md) | 관련 절 열람·전문 정독으로 집계하지 않음 | `8866a682` |
| [docs/증거카드_이상형과_추출방법.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/%EC%A6%9D%EA%B1%B0%EC%B9%B4%EB%93%9C_%EC%9D%B4%EC%83%81%ED%98%95%EA%B3%BC_%EC%B6%94%EC%B6%9C%EB%B0%A9%EB%B2%95.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/카드생성논리_상세설명.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/%EC%B9%B4%EB%93%9C%EC%83%9D%EC%84%B1%EB%85%BC%EB%A6%AC_%EC%83%81%EC%84%B8%EC%84%A4%EB%AA%85.md) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [docs/페르소나_P1_취준생_v3_0.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/%ED%8E%98%EB%A5%B4%EC%86%8C%EB%82%98_P1_%EC%B7%A8%EC%A4%80%EC%83%9D_v3_0.md) | 전문 열람 | `8866a682` |
| [docs/페르소나_P2_HR리크루터_v2_0.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/%ED%8E%98%EB%A5%B4%EC%86%8C%EB%82%98_P2_HR%EB%A6%AC%ED%81%AC%EB%A3%A8%ED%84%B0_v2_0.md) | 전문 열람 | `8866a682` |
| [docs/페르소나_P3_기술면접관_v3_0.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/%ED%8E%98%EB%A5%B4%EC%86%8C%EB%82%98_P3_%EA%B8%B0%EC%88%A0%EB%A9%B4%EC%A0%91%EA%B4%80_v3_0.md) | 전문 열람 | `8866a682` |
| [docs/페르소나_P4_운영자_v2_0.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/%ED%8E%98%EB%A5%B4%EC%86%8C%EB%82%98_P4_%EC%9A%B4%EC%98%81%EC%9E%90_v2_0.md) | 전문 열람 | `8866a682` |
| [web/.gitignore](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/web/.gitignore) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [web/README.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/web/README.md) | 전문 열람 | `8866a682` |
| [worker/.gitignore](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/worker/.gitignore) | 목록·문서 지위 확인만; 화면 근거로 미채택 | `8866a682` |
| [worker/README.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/worker/README.md) | 전문 열람 | `8866a682` |
