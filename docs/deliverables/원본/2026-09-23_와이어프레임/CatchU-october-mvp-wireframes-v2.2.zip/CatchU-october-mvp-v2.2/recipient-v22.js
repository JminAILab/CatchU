'use strict';
// 사용자가 전달한 팀장 검토안. 실제 AI 호출·JD 저장·채용 판정은 하지 않는다.
(()=>{
 const states={jdPreset:'JD 프리셋 기준 요약',jdCustom:'직접 입력한 JD 기준 요약',portfolio:'포트폴리오 · 준비 중',coverLetter:'자기소개서 · 준비 중',resume:'이력서 · 준비 중',rag:'RAG 질문 입력',ragAnswer:'RAG 답변·근거 예시'};
 Object.assign(byId.V02.states,states);
 byId.V02.name='비로그인 수신자 · 자료 탭·AI 요약';
 const tabs=[['portfolio','포트폴리오'],['coverLetter','자기소개서'],['resume','이력서'],['github','공개 GitHub 자산'],['rag','RAG 질의응답']];
 const presets={backend:{name:'백엔드 개발자',text:'API 설계, 입력값 검증, 오류 처리, 테스트 작성 경험'},frontend:{name:'프론트엔드 개발자',text:'사용자 입력 처리, 화면 상태 관리, 접근성, UI 테스트 경험'},data:{name:'데이터 엔지니어',text:'데이터 수집·정제, 파이프라인 운영, 품질 검증 경험'}};
 let view;
 const previous={initial,seedScreen,action,noteText};
 function reset(){view={tab:'github',jd:null,question:'',answer:false};}
 reset();
 initial=function(){previous.initial();reset();};
 seedScreen=function(id,state){previous.seedScreen(id,state);if(id!=='V02')return;
  if(['portfolio','coverLetter','resume','rag'].includes(state))view.tab=state;
  if(state==='jdPreset')view.jd={...presets.backend,kind:'preset',key:'backend'};
  if(state==='jdCustom')view.jd={name:'직접 입력한 JD',text:'API 응답 규격과 입력값 검증 경험을 확인하고 싶습니다.',kind:'custom'};
  if(state==='ragAnswer'){view.tab='rag';view.question='입력값 검증과 테스트 경험의 근거를 알려 주세요.';view.answer=true;}
 };
 function available(){return mode==='empty'?[]:publicCatches();}
 function scopeLabel(){return view.tab==='rag'?'공개 GitHub 자산 · RAG':tabs.find(([key])=>key===view.tab)[1];}
 function focusButton(selector){render();$(selector)?.focus();}
 function summary(catches){
  const future=['portfolio','coverLetter','resume'].includes(view.tab),jd=view.jd;
  let body;
  if(future)body='<p>이 자료는 준비 중입니다. 자료가 제공되면 현재 화면을 기준으로 요약합니다.</p>';
  else if(!catches.length)body='<p>현재 요약할 수 있는 공개 GitHub 자산이 없습니다.</p>';
  else body=`<h3>${jd?'JD 기준 검토 요약':'일반 요약'}</h3><p>현재 공개된 ${catches.length}개 작업의 사실·기여·근거를 확인할 수 있습니다.</p>${jd?`<p>${jd.key==='backend'?'API 응답과 입력 검증, 테스트 경험을 JD와 함께 살펴봅니다.':jd.key==='frontend'?'사용자 입력 처리 경험과 관련 근거를 JD와 함께 살펴봅니다.':jd.key==='data'?'데이터 검증 관련 경험을 확인하고, 수집·파이프라인 경험은 추가 근거가 필요한지 살펴봅니다.':'입력한 담당 업무·역량과 관련된 공개 근거를 확인하는 영역입니다.'}</p><p class="small muted">JD 비교 화면의 예시이며 직무 적합성 판정이 아닙니다.</p>`:'<p>공개된 작업 사실과 기여, 연결된 근거를 중심으로 요약합니다.</p>'}<ul class="summary-sources">${catches.map(c=>`<li>${esc(c.title)}<small>${esc(c.evidence)}</small></li>`).join('')}</ul>`;
  return `<aside class="recipient-ai" aria-labelledby="recipient-ai-title"><div class="row"><h2 id="recipient-ai-title">AI 화면 요약</h2><span class="badge">예시</span></div><p class="small muted">현재 보는 자료 · ${esc(scopeLabel())}</p><div class="jd-current"><span class="small muted">요약 기준</span><strong>${jd?esc(jd.name):'일반 정보'}</strong>${jd?`<p class="small">${esc(jd.text)}</p>`:'<p class="small">JD가 없으면 일반 정보로 요약합니다.</p>'}</div>${btn('기업 JD 선택·직접 입력','recipient-jd-open')}<div class="ai-summary-body" aria-live="polite">${body}</div><p class="small muted">현재 링크에서 열람 가능한 자료만 사용합니다.</p></aside>`;
 }
 function ragPanel(catches){
  return `<h2>RAG 질의응답</h2><p class="small muted">${view.jd?esc(view.jd.name)+' 기준으로':'공개된 작업과 근거를 바탕으로'} 질문하고 연결된 자료를 확인합니다.</p><form id="recipient-rag-form" class="stack"><label>자료에 대해 질문하기<textarea name="question" maxlength="1000" placeholder="예: 입력값 검증 경험의 근거를 알려 주세요." ${catches.length?'':'disabled'}>${esc(view.question)}</textarea></label><div id="rag-validation" role="alert"></div>${btn('질문하기 · 예시','recipient-rag-ask',true,!catches.length)}</form>${!catches.length?notice('질문할 수 있는 공개 자료가 없습니다.'):''}${view.answer?`<section class="rag-answer" aria-live="polite"><span class="badge">고정 답변 예시</span><h3>공개 근거에서 확인한 내용</h3><p>${catches.map(c=>esc(c.draft||c.fact)).join(' ')}</p><p class="small muted">질의응답 흐름을 검토하기 위한 예시 답변입니다.</p><h3>연결된 근거</h3>${catches.map(c=>`<div class="rag-source"><p>${esc(c.title)}<small>${esc(c.evidence)}</small></p>${btn('근거 확인','recipient-catch',false,false,`data-id="${esc(c.id)}"`)}</div>`).join('')}</section>`:''}`;
 }
 recipientList=function(){
  const supported=['normal','empty',...Object.keys(states)];
  if(recipientGate()!=='ok'||!supported.includes(mode))return original.recipientList().replace('<h1>공개 자료</h1>','<h1>자료 열람</h1>');
  const catches=available(),future=['portfolio','coverLetter','resume'].includes(view.tab);
  const tabbar=`<div class="recipient-tabs" role="tablist" aria-label="자료 종류">${tabs.map(([key,label])=>`<button type="button" role="tab" id="recipient-tab-${key}" aria-selected="${view.tab===key}" aria-controls="recipient-tab-panel" tabindex="${view.tab===key?'0':'-1'}" data-action="recipient-tab" data-tab="${key}">${label}${['portfolio','coverLetter','resume'].includes(key)?'<small>준비 중</small>':''}</button>`).join('')}</div>`;
  const panel=future?`<div class="future-document-panel"><span class="badge">준비 중</span><h2>${esc(scopeLabel())}</h2><p>${esc(scopeLabel())}를 이 탭에서 열람할 수 있도록 준비하고 있습니다.</p></div>`:view.tab==='rag'?ragPanel(catches):`<div class="heading-row"><h2>공개 GitHub 자산</h2><span class="small muted">${catches.length}개 자료</span></div>${catches.length?`<div class="list">${catches.map(c=>catchRow(c,true)).join('')}</div>`:empty('현재 열람할 수 있는 공개 GitHub 자산이 없습니다.')}`;
  return `<div class="recipient-profile">${profileCard()}</div><div class="recipient-review-layout">${summary(catches)}<div class="recipient-content">${tabbar}<section id="recipient-tab-panel" role="tabpanel" aria-labelledby="recipient-tab-${view.tab}" tabindex="0">${panel}</section></div></div>`;
 };
 function openJD(){
  const jd=view.jd;
  showDialog('기업 JD로 요약 기준 설정',`<p class="small">직무 프리셋을 선택하거나 회사의 채용공고(JD)를 직접 입력하세요.</p><form id="recipient-jd-form" class="stack"><fieldset><legend>입력 방식</legend><label class="check"><input type="radio" name="kind" value="preset" ${jd?.kind!=='custom'?'checked':''}><span>JD 프리셋 선택</span></label><label class="check"><input type="radio" name="kind" value="custom" ${jd?.kind==='custom'?'checked':''}><span>회사 JD 직접 입력</span></label></fieldset><label id="jd-preset-field" ${jd?.kind==='custom'?'hidden':''}>직무 프리셋 · 예시<select name="preset">${Object.entries(presets).map(([key,p])=>`<option value="${key}" ${jd?.key===key?'selected':''}>${p.name}</option>`).join('')}</select></label><label id="jd-custom-field" ${jd?.kind!=='custom'?'hidden':''}>회사 JD 내용<textarea name="jd" maxlength="3000" placeholder="담당 업무, 필수 역량, 우대사항 등을 입력하세요.">${jd?.kind==='custom'?esc(jd.text):''}</textarea></label><div id="jd-validation" role="alert"></div></form><p class="small muted">JD를 사용하지 않으면 일반 정보로 요약합니다.</p>`,btn('취소','close')+btn('JD 없이 일반 요약','recipient-jd-clear')+btn('JD 적용','recipient-jd-apply',true));
 }
 action=function(a,el){
  if(a.startsWith('recipient-')&&a!=='recipient-catch'){
   if(screen.id!=='V02'||recipientGate()!=='ok')return;
   if(a==='recipient-tab'){view.tab=el.dataset.tab;focusButton(`#recipient-tab-${view.tab}`);return;}
   if(a==='recipient-jd-open'){openJD();return;}
   if(a==='recipient-jd-clear'){view.jd=null;view.answer=false;closeDialog();focusButton('[data-action="recipient-jd-open"]');return;}
   if(a==='recipient-jd-apply'){
    const f=$('#recipient-jd-form'),values=new FormData(f),custom=String(values.get('jd')||'').trim();
    if(values.get('kind')==='custom'&&!custom){$('#jd-validation').textContent='회사 JD를 입력하거나 일반 요약을 선택해 주세요.';f.elements.jd.focus();return;}
    const key=String(values.get('preset'));
    view.jd=values.get('kind')==='custom'?{kind:'custom',name:'직접 입력한 JD',text:custom}:{...presets[key],kind:'preset',key};view.answer=false;closeDialog();focusButton('[data-action="recipient-jd-open"]');return;
   }
   if(a==='recipient-rag-ask'){
    if(!available().length)return;
    view.question=$('#recipient-rag-form textarea').value.trim();
    if(!view.question){$('#rag-validation').textContent='질문을 입력해 주세요.';$('#recipient-rag-form textarea').focus();return;}
    view.answer=true;render();$('#recipient-rag-form textarea').focus();return;
   }
  }
  if(a==='open-recipient')reset();
  previous.action(a,el);
 };
 document.addEventListener('change',e=>{if(e.target.matches('#recipient-jd-form input[name="kind"]')){$('#jd-preset-field').hidden=e.target.value!=='preset';$('#jd-custom-field').hidden=e.target.value!=='custom';$('#jd-validation').textContent='';}});
 document.addEventListener('input',e=>{if(e.target.matches('#recipient-rag-form textarea'))view.question=e.target.value;});
 document.addEventListener('submit',e=>{if(e.target.id==='recipient-rag-form'){e.preventDefault();action('recipient-rag-ask');}if(e.target.id==='recipient-jd-form'){e.preventDefault();action('recipient-jd-apply');}});
 document.addEventListener('keydown',e=>{
  const tab=e.target.closest('.recipient-tabs [role="tab"]');if(!tab||!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
  e.preventDefault();const index=tabs.findIndex(([key])=>key===view.tab),next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(index+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;action('recipient-tab',{dataset:{tab:tabs[next][0]}});
 });
 noteText=function(){let html=previous.noteText();if(screen.id!=='V02')return html;
  html=html.replace(/<aside class="review-note"><strong>팀장 검토 의견 반영<\/strong>[\s\S]*?<\/aside>/,'');
  return html+'<aside class="review-note"><strong>팀장 검토안 v2.2 · 자료 탭 / AI 요약 / JD / RAG</strong><p>자료 종류는 상단 탭으로, 왼쪽 사이드바는 현재 화면의 AI 요약으로 바꿨습니다. 기업 JD 프리셋·직접 입력을 선택하고, JD가 없으면 일반 요약을 봅니다. RAG는 사용자가 확인한 질의응답 탭입니다.</p><p>추가 기획을 검토하는 합성 예시입니다. 문서 3종은 준비 중이며, 실제 AI 응답·회사별 프리셋·출시 범위·데이터 계약을 확정하지 않습니다.</p></aside>';
 };
 const selectedId=screen?.id,selectedState=mode;
 if(selectedId==='V02')seedScreen(selectedId,selectedState);
 render();
})();

