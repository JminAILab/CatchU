'use strict';
const catalog=window.wireframeCatalogue;
const selected={
 'H-01':['normal','unlinked','linked','ready'],W01:['normal'],'W01-R':['missing'],W02:['normal','edit'],'W02-P':['normal','modal'],'W02-G':['normal'],
 W03:['normal','history','empty'],'A-01':['normal','selected','accepted'],'A-02':['running','complete','zero','partial','preparing'],'A-03':['normal','accepted'],
 'W03-R':['normal','single'],W04:['unconfirmed','noDraft','public','mismatch'],W05:['normal'],
 L01:['normal','password','empty'],L02:['normal'],L03:['examples','confirm'],V01:['normal'],V02:['normal','jdPreset','ragAnswer','empty'],V03:['normal','noDraft','protected']
};
const descriptions={
 W01:'Google 로그인 진입입니다. 로그인과 GitHub 연결은 별도의 행동이며 분석이나 공개를 자동 실행하지 않습니다.',
 'W01-R':'로그인 성공 이후 표시 이름 저장 여부를 조회합니다. 조회 실패를 미가입·이름 미저장으로 판단하지 않습니다.',
 W02:'표시 이름과 선택 프로필을 입력합니다. 최초 저장 후 홈, 수정 저장·취소 후 상세 프로필로 돌아갑니다. 실패 시 입력 유지, 미저장 이탈 확인을 비교합니다.',
 'W02-P':'프로필 메뉴에는 보기와 로그아웃을 둡니다. 상세에서 프로필 수정과 GitHub 연결로 이동합니다.',
 'W02-G':'CatchU 로그인과 GitHub 연결 상태를 분리합니다. 연결 완료는 분석 동의나 분석 요청을 뜻하지 않습니다.',
 'H-01':'비로그인 / GitHub 연결 전 / 레포 연결 전 / 레포 연결 후. 홈은 분석별 상태·결과 수를 집계하지 않습니다.',
 W03:'내 Catch 탭과 GitHub 분석 이력 탭. 포트폴리오·자기소개서·이력서는 준비 중 안내로 표시합니다. 분석 화면을 떠난 뒤 같은 작업을 다시 찾는 진입점입니다.',
 'A-01':'선정된 공개 저장소를 고르고 대상별 안내를 읽은 뒤 하나의 동의·요청 버튼으로 제출합니다. 접수 불명은 재제출 대신 상태 확인으로 연결합니다.',
 'A-02':'접수·진행·반영 대기·완료·정상 0건·부분 실패·초안 실패·조회 실패를 구분합니다. 후보 존재만으로 결과 버튼을 활성화하지 않습니다.',
 'A-03':'실패를 확인한 뒤 사용자가 명시적으로 다시 요청합니다. 허용 조건은 미결입니다. 조건 충족 예시는 연결 검토를 위한 가정이며 실제 허용 규칙이 아닙니다.',
 'W03-R':'해당 분석의 Catch 목록입니다. 1개도 목록을 거쳐 상세로 이동합니다. 정상 0건과 조회 실패를 구분합니다.',
 W04:'작업 사실·본인 기여·생성 설명·원본 근거·질문을 나눕니다. 명시 확인과 공개는 별도이며, 불일치 표시 시 공개 자료에서도 제외됩니다.',
 W05:'확인 완료 직후에도 미공개입니다. 설명 초안이 없는 Catch도 다른 등록·공개 조건을 충족하면 공개 선택이 가능합니다.',
 L01:'현재 공개 자료를 확인하고 제목·선택 비밀번호를 입력합니다. 유효 제목 중복을 우선 확인하며 유효 링크 최대 5개, 발행 후 30일입니다. 공개 Catch 없이 프로필만 공유할 수 있습니다.',
 L02:'발행된 URL과 만료·비밀번호 설정 여부를 확인합니다. URL은 합성 예시이며 실제 인터넷 공유 링크가 아닙니다.',
 L03:'유효·중단·만료 링크를 관리합니다. 링크 중단은 링크 단위 열람 중지이며 Catch를 숨기거나 삭제하는 행동과 다릅니다.',
 V01:'비밀번호를 설정한 링크의 수신자 진입입니다. 링크 중단·만료 확인이 비밀번호 입력보다 먼저 적용됩니다.',
 V02:'자료 종류별 탭과 AI 화면 요약을 나란히 봅니다. 기업 JD 프리셋·직접 입력을 적용하거나 일반 요약으로 돌아갑니다. RAG 탭에서 질문·예시 답변·공개 근거 확인을 연결합니다. 세 문서는 준비 중이며, JD·AI·RAG는 팀장 추가 기획 검토안입니다.',
 V03:'같은 링크의 공개 Catch와 근거를 확인합니다. 숨김·원본 비공개·중단·만료에 따른 제한과 일시 조회 실패를 구분합니다.'
};
const q=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const url=(id,state)=>`player.html?preview=${id}#${id}?state=${state}`;
function card(s,state){const title=s.states[state],src=`screens/${s.id}-${state}.png`;return `<article class="card"><header class="card-head"><div class="id"><span>${s.id}</span><span>${s.group}</span></div><h3>${esc(s.name)}</h3><p>${esc(title)}</p></header><a href="${src}" data-image="${src}" data-title="${esc(s.id+' · '+s.name+' / '+title)}" aria-label="${esc(s.name+' '+title+' 확대')}"><div class="frame"><img src="${src}" loading="lazy" alt="${esc(s.name+' · '+title+' 와이어프레임')}"></div></a><div class="card-actions"><a href="${url(s.id,state)}">직접 조작 →</a><a href="#states" data-state="${s.id}">이 화면의 ${Object.keys(s.states).length}개 상태</a></div></article>`;}
function board(){const group=q('#group-filter').value,term=q('#screen-search').value.trim().toLowerCase();let count=0;const groups=['회원·홈','자산·분석','Catch 확인·공개','링크·수신자'];q('#all-boards').innerHTML=groups.filter(g=>group==='all'||group===g).map((g,i)=>{const rows=Object.keys(selected).map(id=>catalog.find(s=>s.id===id)).filter(s=>s.group===g&&(!term||`${s.id} ${s.name} ${Object.values(s.states).join(' ')}`.toLowerCase().includes(term)));if(!rows.length)return '';const cards=rows.flatMap(s=>selected[s.id].map(st=>card(s,st)));count+=cards.length;return `<div class="group"><div class="group-heading"><h3>${String(i+1).padStart(2,'0')} / ${g}</h3><span>${rows.length}개 화면 유형 · ${cards.length}개 배치</span></div><div class="cards">${cards.join('')}</div></div>`}).join('')||'<p class="empty">일치하는 화면이 없습니다. 필터를 초기화해 주세요.</p>';q('#visible-count').textContent=`대표 화면 ${count}개 표시`;}
function states(id){q('#state-screen').value=id;const s=catalog.find(s=>s.id===id);q('#state-summary').textContent=Object.keys(s.states).length+'개 상태를 나란히 비교';q('#screen-detail').innerHTML=`<div class="eyebrow">${s.id} / ${s.group}</div><h3>${esc(s.name)}</h3><p>${descriptions[id]}</p>`;q('#state-grid').innerHTML=Object.keys(s.states).map(st=>card(s,st)).join('');}
q('#board-count').textContent=Object.values(selected).flat().length;q('#state-count').textContent=catalog.reduce((n,s)=>n+Object.keys(s.states).length,0);q('#state-screen').innerHTML=catalog.map(s=>`<option value="${s.id}">${s.id} · ${s.name}</option>`).join('');q('#state-screen').addEventListener('change',e=>states(e.target.value));q('#group-filter').addEventListener('change',board);q('#screen-search').addEventListener('input',board);q('#clear-filter').addEventListener('click',()=>{q('#group-filter').value='all';q('#screen-search').value='';board()});
document.addEventListener('click',e=>{const img=e.target.closest('[data-image]'),st=e.target.closest('[data-state]'),focus=e.target.closest('[data-focus]');if(img){e.preventDefault();q('#image-title').textContent=img.dataset.title;q('#large-image').src=img.dataset.image;q('#large-image').alt=img.dataset.title;q('#image-dialog').showModal();}if(st){states(st.dataset.state)}if(focus){q('#group-filter').value='all';q('#screen-search').value=focus.dataset.focus;board();}});q('#close-image').addEventListener('click',()=>q('#image-dialog').close());board();states('A-02');
