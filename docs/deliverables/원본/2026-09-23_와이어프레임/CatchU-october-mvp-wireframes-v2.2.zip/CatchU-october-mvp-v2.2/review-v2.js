'use strict';
// 2026-09-23 전체 검토본. 원본 app.js의 합성 자료를 재사용한다.
// 파일/네트워크 저장 없음. 미결 정책을 실제 서비스 동작으로 확정하지 않는다.
const extraStates={
 'W01':{unknown:'로그인 응답 확인 불가'},
 'W01-R':{expired:'조회 중 세션 만료',logoutError:'로그아웃 실패'},
 'W02':{emptyName:'표시 이름 미입력',unsaved:'수정 중 · 미저장 변경',logoutError:'로그아웃 실패 · 입력 유지'},
 'W02-G':{checking:'연결 상태 조회 중',reauth:'GitHub 권한 만료',expired:'CatchU 세션 만료'},
 'H-01':{loading:'연결 상태 조회 중',authLoading:'로그인 여부 확인 중',authError:'로그인 여부 조회 실패',expired:'로그인 세션 만료'},
 'W03':{resultError:'이력의 결과 수 조회 실패'},
 'A-01':{expired:'요청 전 세션 만료'},
 'A-02':{recovering:'결과 반영 복구 중',partialPending:'일부 실패 · 열람 준비 미확인',missing:'분석 없음 · 본인 분석 아님',loading:'현재 상태 조회 중'},
 'A-03':{allowed:'재요청 조건 충족 가정',partialPending:'일부 실패 · 제공 가능 결과 미확인',loading:'현재 상태 조회 중',missing:'분석 없음 · 본인 분석 아님',currentRunning:'이미 다시 진행 중',currentComplete:'이미 완료 상태',expired:'세션 만료'},
 'W03-R':{missing:'분석 대상·진입 출처 확인 불가'},
 'W04':{saving:'확인 저장 중',saveUnknown:'확인 저장 여부 불명',hideError:'숨김 저장 실패',mismatchError:'불일치 저장 실패'},
 'W05':{unknown:'공개 저장 여부 불명'},
 'L03':{confirm:'중단 전 영향 확인'},
 'V02':{loading:'최초 자료 조회 중',followupError:'열람 중 후속 조회 실패'},
 'V03':{loading:'상세 조회 중',followupError:'열람 중 후속 조회 실패'}
};
for(const [id,states] of Object.entries(extraStates))Object.assign(byId[id].states,states);
const original={initial,render,action,productContent,noteText,analysisPage,failurePage,profileForm,assetsPage,nav,stateTo,applyFixture};
original.recipientList=recipientList;
profileCard=function(){return `<div class="profile-display"><div class="profile-placeholder" aria-hidden="true">○</div><div><h2>${esc(data.profile.name)}</h2><p>${esc(data.profile.intro)}</p><p class="small">${esc(data.profile.role)} · ${esc(data.profile.tech)} <span class="muted">— 직접 입력한 정보</span></p><p class="small muted">${data.linked?'GitHub · sample-garam':'GitHub 미연결'}</p></div></div>`;};
let profileEditing=false,pendingExit=null,resultMode='normal',returnFocus=null;
initial=function(){original.initial();profileEditing=false;pendingExit=null;resultMode='normal';ui.sessionReturn=null;};
function seedScreen(id,state){
 initial();data.logged=!['W01','H-01'].includes(id);data.linked=!['W01','W01-R','W02','W02-G'].includes(id);
 data.requested=true;data.analysis='complete';
 if(id==='H-01'){data.logged=state!=='normal';data.linked=['linked','ready'].includes(state);data.requested=state==='ready';}
 if(id==='W02'){profileEditing=['edit','unsaved','logoutError'].includes(state);if(state==='emptyName')data.profile.name='';if(state==='unsaved'||state==='logoutError')ui.profileDraft={...data.profile,intro:'수정 중인 한 줄 소개'};}
 if(id==='W03'&&['history','resultError','unlinked'].includes(state))ui.tab='github';
 if(id==='W03'&&state==='empty')data.catches=[];
 if(id.startsWith('A-')){ui.tab='github';data.analysis=state;data.requested=id!=='A-01';}
 if(id==='W03-R'){resultMode=state;ui.resultReturn='A-02';}
 if(id==='W04'){ui.detailReturn='W03-R';if(state==='hideError'||state==='mismatchError'){data.catches[0].visibility='public';data.catches[0].confirmed=true;}}
 if(id==='W02-P')ui.profileReturn='H-01';
 if(id.startsWith('L')||id.startsWith('V')){
  data.catches.forEach(c=>{c.confirmed=true;c.visibility='public'});
  if(id!=='L01'){const l=makeLink('팀 검토용 전달','', 'valid','review-link');data.links=[l];data.currentLink=l.id;data.hasIssued=true;data.catches.forEach(c=>data.issuedIds.add(c.id));}
  if(id==='V01'){data.links[0].password='검토1234';}
 }
 original.applyFixture(id,state);
 if(id==='W04'&&state==='noDraft')data.catches[0].draft=null;
 if(id==='W05'&&state==='noDraft')data.catches[0].draft=null;
 ui.lastFixture=id+':'+state;ui.states[id]=state;
}
stateTo=function(state){const id=screen.id;closeDialog();seedScreen(id,state);history.replaceState(null,'',route(id,state));render();$('#state-picker')?.focus();};
function dirtyProfile(){return !!ui.profileDraft&&JSON.stringify(ui.profileDraft)!==JSON.stringify(data.profile);}
function askExit(proceed,logout=false){
 if(!dirtyProfile()){proceed();return;}
 pendingExit=()=>{if(!logout)ui.profileDraft=null;proceed();};
 showDialog('작성한 내용을 저장하지 않고 나갈까요?','<p>계속 작성하면 현재 화면과 입력을 유지합니다.</p>'+(logout?'<p>로그아웃에 동의해도 성공이 확인되기 전까지 입력을 유지합니다.</p>':''),btn('계속 작성','close')+btn('나가기','exit-confirm',true));
}
nav=function(id,state){
 if(screen?.id==='W02'&&id!=='W02'&&dirtyProfile()){askExit(()=>original.nav(id,state));return;}
 if(id==='W02'&&state==='edit')profileEditing=true;
 if(id==='W03-R'&&!state&&ui.detailReturn==='W03-R')state=resultMode;
 original.nav(id,state);
};
shell=function(content){
 const id=screen.id,recipient=id.startsWith('V'),guest=id==='H-01'&&['normal','expired'].includes(mode),onboarding=id==='W01-R'||id==='W02'&&!profileEditing;
 let menu='';
 if(guest)menu=link('Google로 시작하기','W01','normal');
 else if(onboarding)menu=btn('로그아웃','logout');
 else if(!recipient&&id!=='W01')menu=`${link('내 자산','W03')}${link('공유 링크','L03')}<button type="button" class="future" data-action="jobs">채용공고 <small>준비 중</small></button><span class="future nonaction">알림 · 준비 중</span>${btn('프로필','profile')}`;
 if(id==='H-01'&&['authLoading','authError'].includes(mode))menu='';
 const brand=recipient||onboarding||id==='W01'?'<span class="product-brand">CatchU</span>':`<a class="product-brand" href="#H-01?state=${guest?'normal':data.linked?data.requested?'ready':'linked':'unlinked'}">CatchU</a>`;
 return `<section class="product" aria-label="제품 화면 예시"><header class="product-header">${brand}<nav class="product-nav" aria-label="서비스 탐색">${menu}</nav></header><div class="product-body" id="product-content">${content}</div><div class="footer-note">흑백 와이어프레임 · 합성 예시</div></section>`;
};
openProfile=function(){ui.profileReturn=screen?.id==='W02-P'?ui.profileReturn:screen?.id||'H-01';showDialog('내 프로필',`<p>${esc(data.profile.name)}</p>`,btn('프로필 보기','profile-view',true)+btn('로그아웃','logout')+btn('닫기','close'));};
homePage=function(){
 const guest=mode==='normal';
 if(guest)return `<div class="narrow"><p class="eyebrow">GitHub 기록에서 내 경험 찾기</p><h1>내가 한 일을,<br>근거와 함께 전달하세요.</h1><p>작업 기록에서 경험 후보를 찾고 직접 확인한 Catch를 공유합니다.</p><div class="box soft"><p class="small">가상 Catch 예시</p><h2>빈 목록 응답 형식 정리</h2><p>무엇을 했나 → 근거 → 설명 초안 → 나의 확인</p></div><div class="actions">${link('Google로 시작하기','W01','normal',true)}</div></div>`;
 const loading=mode==='loading',error=mode==='error',unlinked=mode==='unlinked',ready=mode==='ready';
 return `<h1>${esc(data.profile.name)}님, 안녕하세요.</h1><p>내 기록을 확인하고 공유할 경험을 준비하세요.</p><ol class="connection-steps"><li class="${unlinked?'current':''}">${unlinked?'현재 단계 · ':''}1. GitHub 연결</li><li class="${mode==='linked'?'current':''}">${mode==='linked'?'현재 단계 · ':''}2. 레포 연결</li></ol>${loading?notice('연결 상태를 확인하고 있습니다.','연결 여부가 확인되기 전에는 다음 단계를 확정하지 않습니다.'):error?err('연결 상태를 불러오지 못했습니다. GitHub 미연동이나 저장소 없음으로 판단하지 않습니다.')+btn('다시 불러오기','reload',true):ready?`<div class="two-col"><div class="box"><h2>내 자산 확인</h2><p>GitHub 탭에서 요청한 분석을, 내 Catch 탭에서 경험을 확인하세요.</p>${btn('내 자산으로','github-tab',true)}</div><div class="box"><h2>공유 링크 관리</h2><p>공개한 자료를 전달하고 링크 상태를 확인하세요.</p>${link('공유 링크로','L03')}</div></div>`:`<div class="box"><h2>${unlinked?'GitHub 계정을 연결해 주세요.':'분석할 저장소를 연결해 주세요.'}</h2><p>${unlinked?'분석 전에 GitHub 계정 연결이 필요합니다. 연결만으로 분석은 시작되지 않습니다.':'내 자산의 GitHub 탭에서 저장소를 선택하고 분석 내용에 동의합니다.'}</p>${unlinked?link('연결하러 가기','W02-G','normal',true):btn('내 자산에서 레포 연결','github-tab',true)}</div>`}`;
};
profileForm=function(){
 if(mode==='loadError')return '<h1>프로필 수정</h1>'+err('저장된 프로필을 불러오지 못했습니다.')+btn('다시 불러오기','reload',true)+link('상세 프로필로','W02-P','normal');
 const edit=profileEditing||mode==='edit',p=ui.profileDraft||data.profile,busy=mode==='saving';
 return `<div class="narrow"><h1>${edit?'프로필 수정':'기본 프로필'}</h1><p>${edit?'서비스에 저장된 정보를 수정합니다.':'사용할 표시 이름을 확인해 주세요.'}</p><form id="profile-form" class="stack"><label>표시 이름<input name="name" value="${esc(p.name)}" autocomplete="off" ${busy?'disabled':''}></label><p class="small muted">${edit?'Google에서 다시 받은 이름으로 덮어쓰지 않습니다.':'Google 이름을 받은 경우 미리 채우며 수정할 수 있습니다.'}</p>${[['intro','한 줄 소개'],['role','직무'],['tech','기술 스택']].map(([k,t])=>`<label>${t} (선택)<input name="${k}" value="${esc(p[k])}" ${busy?'disabled':''}></label>`).join('')}<p class="small muted">직무·기술 스택은 직접 입력한 정보입니다. 선택 정보는 나중에 작성할 수 있습니다.</p>${edit?notice('프로필 수정은 기존 공유 링크의 다음 조회에도 반영됩니다.'):notice('GitHub 계정 없이도 홈을 이용할 수 있습니다.')}<div id="profile-validation" role="status">${mode==='emptyName'?err('표시 이름을 입력해 주세요.'):mode==='error'?err('저장하지 못했습니다. 입력 내용을 유지합니다.'):mode==='unknown'?notice('저장 여부를 확인하지 못했습니다.','저장된 프로필을 확인해 주세요.'):mode==='logoutError'?err('로그아웃하지 못했습니다. 화면과 입력을 유지합니다.'):''}</div><div class="actions">${edit?btn('취소','profile-cancel',false,busy):''}${mode==='unknown'?btn('저장된 프로필 확인','profile-reload',true):btn(busy?'저장 중…':edit?'저장':'저장하고 홈으로','profile-save',true,busy)}</div></form></div>`;
};
analysisPage=function(){
 if(['recovering','partialPending'].includes(mode))return `${back('내 자산 · GitHub','W03')}<h1>분석 상태</h1><div class="box"><h2>${esc(data.repo)}</h2>${mode==='recovering'?notice('결과를 준비하고 있습니다.','결과를 반영하는 과정에서 복구를 진행하고 있습니다. 새 분석을 요청하지 않고 기존 작업을 확인합니다.'):notice('일부 분석에 실패했습니다.','제공 가능한 Catch의 등록·열람 준비가 아직 확인되지 않았습니다. 전체 완료나 후보 0건으로 표시하지 않습니다.')}<div class="actions">${btn('상태 다시 불러오기','status-check',true)}${btn('GitHub 탭으로','github-tab')}</div></div>`;
 let html=original.analysisPage();
 html=html.replace(/<ol class="steps">[\s\S]*?<\/ol>/,'').replace('이 화면을 나가도 요청이 취소되지 않습니다. 내 자산의 GitHub 탭에서 다시 확인할 수 있습니다.','이 화면을 떠난 뒤 내 자산의 GitHub 탭에서 같은 분석을 다시 확인할 수 있습니다.');
 if(mode==='partial')html=html.replace('<div class="actions">','<div class="actions">'+link('실패 내용 보기','A-03','partial'));
 if(['zero','insufficient'].includes(mode))html=html.replace('4. 열람 가능','4. 정상 완료 · 새 Catch 없음');
 return html;
};
failurePage=function(){
 if(mode==='partialPending')return `<h1>일부 분석 실패</h1>${notice('현재 확인할 수 있는 결과가 없습니다.','후보의 적합성·등록·열람 준비가 확인되지 않았습니다. 정상 0건과 구분합니다.')}<p>기존 Catch와 공유 링크는 유지됩니다.</p>${btn('상태 확인','status-check',true)}${btn('GitHub 탭으로','github-tab')}`;
 if(mode==='allowed')return `<h1>분석 실패·다시 요청</h1><div class="box"><h2>${esc(data.repo)}</h2>${notice('이전 분석이 실패했습니다.','기존 Catch와 공유 링크는 유지됩니다.')}<p>대상 저장소와 이번 요청의 동의 내용을 다시 확인한 뒤 요청할 수 있습니다.</p>${btn('대상·동의 확인하기','retry-consent',true)}</div>`;
 return original.failurePage();
};
const plannedDocumentTypes=['포트폴리오','자기소개서','이력서'];
function plannedAssetNotice(){return '<div class="planned-asset-notice"><strong>더 다양한 자산을 준비하고 있습니다.</strong><p>포트폴리오·자기소개서·이력서 관리 기능이 추가될 예정입니다.</p></div>';}
assetsPage=function(){
 if(mode==='resultError')return '<h1>내 자산 · GitHub 분석 이력</h1>'+plannedAssetNotice()+'<div class="box"><h2>'+esc(data.repo)+'</h2><p>분석 상태: 완료</p>'+err('결과 수를 불러오지 못했습니다. Catch 0개로 판단하지 않습니다.')+btn('결과 정보 다시 불러오기','reload',true)+'</div>';
 const content=original.assetsPage();
 if(mode==='denied')return content;
 return content.replace(/(<div class="tabs"[^>]*>)([\s\S]*?)(<\/div>)/,(_,open,tabs,close)=>open+tabs+plannedDocumentTypes.map(name=>`<button type="button" class="planned-tab" disabled>${name}<small>준비 중</small></button>`).join('')+close+plannedAssetNotice());
};
recipientList=function(){
 const content=original.recipientList();
 if(recipientGate()!=='ok'||!['normal','empty'].includes(mode))return content;
 const sidebar=`<aside class="planned-sidebar" aria-labelledby="planned-sidebar-title"><h2 id="planned-sidebar-title">자료 탐색</h2><span class="badge">사이드바 추가 예정</span><p class="small muted">자료를 종류별로 찾아볼 수 있는 메뉴가 들어갈 예정입니다.</p><ul><li><span>GitHub 자산</span><small>현재 본문에서 열람</small></li>${plannedDocumentTypes.map(name=>`<li><span>${name}</span><small>준비 중</small></li>`).join('')}</ul></aside>`;
 const documents=`<section class="planned-documents" aria-labelledby="planned-documents-title"><h2 id="planned-documents-title">앞으로 추가될 자료</h2><p class="small muted">포트폴리오·자기소개서·이력서도 이곳에서 만나볼 수 있도록 준비하고 있습니다.</p><div class="planned-document-grid">${plannedDocumentTypes.map(name=>`<div class="planned-document"><h3>${name}</h3><span class="badge">준비 중</span></div>`).join('')}</div></section>`;
 return '<h1>공개 자료</h1><div class="recipient-layout">'+sidebar+'<div class="recipient-main">'+content.replace('<h1>공개 자료</h1>','')+documents+'</div></div>';
};
productContent=function(){
 const id=screen.id;
 if(id==='H-01'&&['authLoading','authError','expired'].includes(mode))return '<h1>'+({authLoading:'로그인 상태를 확인하고 있습니다.',authError:'로그인 상태를 확인하지 못했습니다.',expired:'다시 로그인해 주세요.'}[mode])+'</h1>'+(mode==='authError'?btn('로그인 상태 다시 확인','reload',true):mode==='expired'?link('Google로 시작하기','W01','expired',true):notice('잠시 기다려 주세요.'));
 if(id==='A-02'&&mode==='missing'||id==='A-03'&&mode==='missing')return '<h1>이 분석을 찾을 수 없습니다.</h1>'+link('홈으로','H-01','ready',true);
 if(['A-02','A-03'].includes(id)&&mode==='loading')return '<h1>분석 상태를 불러오는 중입니다.</h1>'+notice('현재 상태를 확인하고 있습니다.');
 if(id==='A-03'&&mode==='expired')return '<h1>다시 로그인해 주세요.</h1>'+link('로그인으로','W01','expired',true);
 if(id==='A-03'&&['currentRunning','currentComplete'].includes(mode))return '<h1>현재 분석 상태</h1>'+notice(mode==='currentRunning'?'이미 분석이 진행 중입니다.':'분석이 완료되었습니다.','실패 상태가 아니므로 다시 요청하지 않습니다.')+(mode==='currentRunning'?link('진행 상태 보기','A-02','running',true):link('결과 확인','W03-R','normal',true));
 if(id==='W01'&&mode==='unknown')return '<h1>로그인 확인</h1>'+notice('로그인 결과를 확인하지 못했습니다.','가입 실패나 계정 없음으로 판단하지 않습니다.')+btn('다시 로그인','login',true);
 if(id==='W01-R'&&mode==='expired'||id==='W02-G'&&mode==='expired'||id==='A-01'&&mode==='expired')return '<h1>다시 로그인해 주세요.</h1>'+notice('로그인이 만료되었습니다.','현재 본인 자료 표시를 중지합니다. 다시 로그인해 상태를 확인하며 분석은 자동 제출하지 않습니다.')+link('로그인으로','W01','expired',true);
 if(id==='W01-R'&&mode==='logoutError')return '<h1>프로필 확인</h1>'+err('로그아웃하지 못했습니다. 현재 화면을 유지합니다.')+btn('로그아웃 다시 시도','logout',true);
 if(id==='W02-G'&&['checking','reauth','unknown','loading'].includes(mode))return `<h1>GitHub 연결</h1>${notice(({checking:'연결 상태를 불러오고 있습니다.',reauth:'GitHub 연결을 다시 확인해 주세요.',unknown:'연결 여부를 확인하지 못했습니다.',loading:'GitHub 연결을 진행하고 있습니다.'})[mode],'CatchU 로그인과 GitHub 권한·연결은 별개입니다. 기존 자료를 삭제하지 않습니다.')}<div class="actions">${mode==='reauth'?btn('다시 연결','connect',true):mode==='unknown'?btn('상태 다시 확인','reload',true):btn('확인 중','none',false,true)}${link('프로필로','W02-P','normal')}</div>`;
 if(id==='W03-R'&&mode==='missing')return '<h1>분석 결과를 확인할 수 없습니다.</h1>'+notice('대상 분석이나 돌아갈 출처를 확인하지 못했습니다.','내 자산의 GitHub 탭에서 분석을 다시 선택해 주세요. 새 분석은 시작하지 않습니다.')+btn('GitHub 탭으로','github-tab',true);
 if(id==='W04'&&['saving','saveUnknown','hideError','mismatchError'].includes(mode)){
  const saved=mode;mode='normal';let html=catchPage();mode=saved;
  const text={saving:'확인 내용을 저장하고 있습니다.',saveUnknown:'확인 저장 여부를 알 수 없습니다. 저장 상태를 먼저 확인해 주세요.',hideError:'숨기지 못했습니다. 기존 공개 상태를 유지합니다.',mismatchError:'불일치를 저장하지 못했습니다. 기존 상태를 유지합니다.'}[saved];
  if(['saving','saveUnknown'].includes(saved))html=html.replace(/data-action="(confirm|mismatch|choose-public)"/g,'disabled data-action="$1"');
  return notice(text)+html+(saved==='saveUnknown'?btn('저장 상태 확인','status-check',true):'');
 }
 if(id==='W05'&&mode==='unknown')return '<h1>공개 상태 확인</h1>'+notice('공개 저장 여부를 확인하지 못했습니다.','공개 완료나 실패로 단정하지 않습니다. 자동으로 다시 공개하지 않습니다.')+btn('공개 상태 다시 확인','status-check',true);
 if(id.startsWith('V')&&mode==='loading')return '<h1>자료를 불러오고 있습니다.</h1>'+notice('열람 조건과 자료를 확인하고 있습니다.','자료 없음으로 처리하지 않습니다.');
 if(id.startsWith('V')&&mode==='followupError'){
  const saved=mode;mode='normal';ui.recipientOverride=null;let html=id==='V02'?recipientList():recipientDetail();mode=saved;
  return notice('새로 요청한 자료를 불러오지 못했습니다.','이전에 열어 둔 화면입니다. 최신 상태를 확인하지 못했으며 새로 요청한 자료는 제공하지 않습니다.')+html+btn('다시 불러오기','reload',true);
 }
 let content=original.productContent();
 if(id==='A-02'&&mode==='partialPending')content+=link('실패 내용 보기','A-03','partialPending');
 if(id==='H-01'&&['loading','error','ready'].includes(mode))content=content.replace(/<ol class="connection-steps">[\s\S]*?<\/ol>/,'');
 return content;
};
noteText=function(){
 let text=original.noteText();
 if(screen.id==='W03')text+='<aside class="review-note"><strong>팀장 검토 의견 반영</strong><p>포트폴리오·자기소개서·이력서는 준비 중 안내로 표시합니다. 실제 문서 업로드·편집·열람 기능이나 제공 시점을 확정하지 않습니다.</p></aside>';
 if(screen.id==='H-01'&&mode==='ready')text+='<aside class="review-note"><strong>미채택 비교안 · #22</strong><p>레포 연결 후 홈의 두 상자는 원작성자의 제외 의견이 있고 대체 구성이 미결입니다. 확정 화면이 아닌 연결 검토안입니다.</p></aside>';
 text=text.replace('이름 필수 여부·길이와 상세 공개 항목 계약','이름 필수 여부·길이·공개 항목의 전달 계약');
 text=text.replace('정책·계약 미결 — 결과 반영 복구 중 기존 작업 반환, 실패 확정·새 요청 허용 시점.','PR #79 최신 입력: 반영 대기·복구 중도 기존 작업을 반환하는 방향. 실패 확정·새 요청 허용 시점은 미결.');
 if(screen.id==='A-03'&&mode==='allowed')text=`<aside class="review-note"><strong>연결 제안 · 조건부 경로</strong><p>실패 확정 및 새 요청 허용 응답이 있다는 가정으로 동의 화면 연결을 검토합니다. 허용 시점·재동의 세부 계약을 확정하지 않습니다. 과거 동의를 재사용하지 않는 검토 경로입니다.</p></aside>`;
 if(['W02','W02-P'].includes(screen.id))text+='<aside class="review-note"><strong>9/23 PR #79 반영</strong><p>프로필 모달은 보기/로그아웃, 수정·연동은 상세에서 진입합니다. 수정 저장·취소 후 상세로, 로그아웃 성공 후 비로그인 홈으로 이동합니다. 표시 이름 필수는 제안이며 미저장 확인창의 표현·닫기 방식은 검토안입니다.</p></aside>';
 return text;
};
action=function(a,el){
 if(a==='confirm-hide'&&mode==='hideError'||a==='confirm-mismatch'&&mode==='mismatchError'){closeDialog();toast('저장 실패 예시 · 기존 상태를 유지합니다.');return;}
 if(a==='jobs'){toast('개발 중입니다.');return;}
 if(a==='exit-confirm'){closeDialog();const fn=pendingExit;pendingExit=null;fn?.();return;}
 if(a==='logout'){
  const finish=()=>{if(mode==='logoutError'){toast('로그아웃 실패 예시 · 입력과 화면을 유지합니다.');return;}ui.profileDraft=null;data.logged=false;closeDialog();original.nav('H-01','normal');};
  askExit(finish,true);return;
 }
 if(a==='profile-cancel'){askExit(()=>{ui.profileDraft=null;original.nav('W02-P','normal')});return;}
 if(a==='profile-save'){
  if(mode==='error'||mode==='saving'){if(mode==='error')toast('저장 실패 예시 · 입력을 유지합니다.');return;}
  const form=$('#profile-form');if(!form)return;const p=Object.fromEntries(new FormData(form));
  if(!p.name.trim()){$('#profile-validation').innerHTML=err('표시 이름을 입력해 주세요.');form.elements.name.focus();return;}
  data.profile=p;ui.profileDraft=null;data.logged=true;original.nav(profileEditing?'W02-P':'H-01',profileEditing?'normal':data.linked?'linked':'unlinked');return;
 }
 if(a==='profile-reload'&&screen.id==='W02'){toast('저장된 프로필 조회 예시 · 상단에서 저장 성공/실패를 비교하세요. 자동 재저장하지 않습니다.');return;}
 if(a==='login'){data.logged=true;original.nav('W01-R','missing');return;}
 if(a==='retry-consent'){ui.selectedRepo=data.repo;ui.notesExtra='재요청 허용 응답 가정';original.nav('A-01','selected');return;}
 if(a==='analysis-results'){resultMode=mode==='partial'?'partial':mode==='draftFail'?'noDraft':'normal';}
 if(a==='partial-results')resultMode='partial';
 if(a==='history-results')resultMode='normal';
 if(a==='reset'){initial();original.nav('W01','normal');return;}
 original.action(a,el);
};
render=function(){
 original.render();
 if(!screen){$('#workspace').innerHTML='<h1>10월 MVP 전체 와이어프레임</h1><p>전체 화면판에서 화면의 배치·연결·예외 상태를 함께 확인하세요.</p><a class="button primary" href="index.html">전체 화면판 열기</a>';return;}
 const first=$('#catalogue nav>a');if(first){first.href='index.html';first.textContent='← 전체 화면판';}
 if(screen.id==='L03'&&mode==='confirm'&&!$('#dialog').open)action('stop-link',{dataset:{id:data.currentLink}});
 if(screen.id==='A-03'&&mode==='accepted'&&!ui.acceptedDialogShown){ui.acceptedDialogShown=true;showDialog('분석을 다시 요청했습니다.','<p>접수가 확인되었습니다. 시작·완료 상태는 진행 화면에서 확인해 주세요.</p>',link('진행 상태 보기','A-02','accepted',true)+btn('닫기','close'));}
};
const preview=new URLSearchParams(location.search).get('preview');
closeDialog();
if(preview&&byId[preview]){const st=new URLSearchParams(location.hash.split('?')[1]||'').get('state')||Object.keys(byId[preview].states)[0];seedScreen(preview,st);}
render();
