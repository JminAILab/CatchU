'use strict';
// 독립된 화면 검토용 상태. 네트워크·영속 저장·인증·실제 분석 기능이 없다.
const screens = [
 ['W01','구직자 로그인','A · 팀원 2','회원·홈',{normal:'기본',cancel:'로그인 취소',error:'로그인 실패',expired:'세션 만료'}],
 ['W01-R','로그인 직후 표시 이름 조회','A · 팀원 2','회원·홈',{loading:'조회 중',error:'조회 실패',missing:'이름 미저장',saved:'이름 저장됨'}],
 ['W02','기본 프로필','A · 팀원 2','회원·홈',{normal:'최초 입력',edit:'프로필 수정',saving:'저장 중',error:'저장 실패',unknown:'저장 여부 불명',loadError:'조회 실패'}],
 ['W02-P','프로필 모달·상세 보기','A · 팀원 2','회원·홈',{normal:'상세 보기',modal:'프로필 모달',loading:'조회 중',error:'조회 실패'}],
 ['W02-G','프로필 GitHub 연결','A · 팀원 2','회원·홈',{normal:'미연동',connected:'연동됨',loading:'연동 중',cancel:'연동 취소',error:'연동 실패',unknown:'연동 상태 확인 불가'}],
 ['H-01','첫 방문·재방문 홈','D · 팀원 3','회원·홈',{normal:'비로그인',unlinked:'로그인 · 미연동',linked:'연동 · 저장소 선택 전',ready:'저장소 연결 후',error:'연결 상태 조회 실패'}],
 ['W03','본인 자산·분석 이력','B · 팀원 4','자산·분석',{normal:'연결된 예시',empty:'빈 Catch·이력',history:'분석 이력 비교',loading:'목록 조회 중',error:'목록 조회 실패',unlinked:'GitHub 미연동',denied:'본인 접근 불가'}],
 ['A-01','저장소 선택·동의','D · 팀원 3 / A·E · 팀원 2','자산·분석',{normal:'선택 전',selected:'저장소 선택·동의 안내',empty:'선정 저장소 0개',loading:'목록 조회 중',error:'목록 조회 실패',denied:'선정·접근 조건 미충족',sending:'요청 전송 중',accepted:'요청 접수',unknown:'접수 여부 불명',duplicate:'같은 저장소 분석 진행 중',reanalysis:'과거 분석 대상 재선택'}],
 ['A-02','분석 상태 확인','D · 팀원 3 / E · 팀원 2','자산·분석',{accepted:'접수 확인',queued:'분석 대기',running:'분석 진행',preparing:'결과 준비 중',complete:'분석 완료 · 결과 있음',zero:'정상 완료 · 후보 0건',insufficient:'정상 완료 · 근거 부족/기준 미달',partial:'일부 분석 실패 · 유효 결과 있음',draftFail:'설명 초안 생성 실패 · Catch 있음',collectionFail:'수집 실패',generationFail:'분석 처리 실패 · 판단 불가',applicationFail:'결과 반영 확인 불가',error:'상태 조회 실패',unknown:'접수 여부 불명',expired:'세션 만료'}],
 ['A-03','실패·명시 재요청','D · 팀원 3 / E·F 연결','자산·분석',{normal:'분석 실패 확인',partial:'일부 실패 · 유효 결과 있음',error:'상태 조회 실패',retry:'재요청 진입 · 정책 미결',sending:'재요청 전송 중 예시',accepted:'재요청 접수 예시',rejected:'재요청 거절 예시',unknown:'접수 여부 불명'}],
 ['W03-R','본인 결과 목록','B · 팀원 4 / D 연결','Catch 확인·공개',{normal:'연결된 결과',single:'Catch 1개',zero:'정상 0건',partial:'부분 실패 결과',noDraft:'초안 없는 Catch 포함',loading:'결과 조회 중',error:'결과 조회 실패',denied:'본인 접근 불가'}],
 ['W04','본인 근거 확인·Catch 상세','B · 팀원 4 / F 의미 연결','Catch 확인·공개',{normal:'연결된 Catch',unconfirmed:'확인 전 · 미공개',confirmed:'확인 완료 · 미공개',noDraft:'초안 없음 · 확인 전',public:'확인 완료 · 공개',hidden:'공개 후 숨김',mismatch:'불일치 표시 · 미공개',saveError:'확인 저장 실패',error:'상세 조회 실패',denied:'본인 접근 불가',protected:'원본 비공개 확인',sourceError:'원본 접근 일시 실패'}],
 ['W05','확인 완료 후 공개 선택','B · 팀원 4 / C 연결','Catch 확인·공개',{normal:'확인 완료 · 미공개',noDraft:'초안 없는 Catch 공개 선택',saving:'공개 저장 중',error:'공개 저장 실패',public:'공개 완료',afterLink:'발행 후 새 공개 · 정책 미결'}],
 ['L01','발행자 링크 발행','C · 팀원 3','링크·수신자',{normal:'발행 준비',empty:'공개 Catch 0개',loading:'공개 자료 조회 중',error:'공개 자료 조회 실패',duplicate:'유효 제목 중복',limit:'유효 링크 5개',password:'선택 비밀번호 사용',sending:'발행 중',failed:'발행 실패',unknown:'발행 여부 불명'}],
 ['L02','링크 발행 결과','C · 팀원 3','링크·수신자',{normal:'발행 완료',password:'비밀번호 설정 링크',copyError:'복사 실패'}],
 ['L03','발행자 링크 관리','C · 팀원 3','링크·수신자',{normal:'연결된 링크',examples:'유효·중단·만료 비교',empty:'발행 링크 없음',loading:'목록 조회 중',error:'목록 조회 실패',stopping:'중단 요청 중',stopError:'중단 실패',stopUnknown:'중단 여부 불명'}],
 ['V01','비로그인 수신자 · 비밀번호','C · 팀원 3','링크·수신자',{normal:'비밀번호 입력',wrong:'비밀번호 불일치',loading:'비밀번호 확인 중',error:'비밀번호 확인 실패',blocked:'중단·만료 우선 거부'}],
 ['V02','비로그인 수신자 · 공개 자료','C · 팀원 3 / A·B 연결','링크·수신자',{normal:'현재 허용된 자료',empty:'공개 자료 0개',error:'자료 조회 실패',denied:'없는 링크 · 접근 거부',stopped:'중단 링크 · 접근 거부',expired:'만료 링크 · 접근 거부',password:'비밀번호 필요'}],
 ['V03','비로그인 수신자 · Catch·근거','C · 팀원 3 / B 연결','링크·수신자',{normal:'현재 허용된 Catch',noDraft:'초안 없는 공개 Catch',hidden:'숨김 Catch 직접 접근',missing:'없는 Catch 직접 접근',protected:'원본 비공개 보호',error:'자료 조회 실패',sourceError:'원본 접근 일시 실패',stopped:'중단 링크 우선 거부',expired:'만료 링크 우선 거부',password:'비밀번호 인증 전'}]
].map(([id,name,owner,group,states])=>({id,name,owner,group,states}));
const byId=Object.fromEntries(screens.map(s=>[s.id,s]));
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const btn=(text,action,primary=false,disabled=false,extra='')=>`<button type="button" data-action="${action}" class="${primary?'primary':''}" ${disabled?'disabled':''} ${extra}>${text}</button>`;
const route=(id,state)=>`#${id}${state?'?state='+encodeURIComponent(state):''}`;
const link=(text,id,state,primary=false)=>`<a class="button ${primary?'primary':''}" href="${route(id,state)}">${text}</a>`;
const badges=(...labels)=>`<div class="badges">${labels.map(s=>`<span class="badge">${esc(s)}</span>`).join('')}</div>`;
const notice=(title,text='')=>`<div class="notice"><strong>${title}</strong>${text?`<p>${text}</p>`:''}</div>`;
const err=text=>`<div class="error" role="alert">${text}</div>`;
const empty=(title,text='',action='')=>`<div class="empty"><h2>${title}</h2><p>${text}</p>${action?`<div class="actions">${action}</div>`:''}</div>`;
const back=(text,id,state)=>`<a class="back" href="${route(id,state)}">← ${text}</a>`;
let data,ui,screen,mode,toastTimer,dialogReturn;
function initial(){
 data={logged:false,linked:false,profile:{name:'김가람',intro:'작업 기록을 근거와 함께 정리합니다.',role:'백엔드 개발',tech:'TypeScript · Node.js'},repo:'sample-lab/record-board',requested:false,analysis:'accepted',links:[],currentLink:null,passwordOK:new Set(),issuedIds:new Set(),hasIssued:false,catches:[
 {id:'c1',title:'빈 목록 응답 형식 정리',fact:'목록이 비어 있을 때 응답의 items 값을 빈 배열로 반환하도록 변경했습니다.',contribution:'김가람이 작성한 변경에서 응답 분기와 빈 목록 테스트 추가를 확인했습니다.',draft:'빈 목록 응답을 빈 배열로 통일하고, 해당 경우를 확인하는 테스트를 추가했습니다.',evidence:'PR #12 · 커밋 a1b2c3d',file:'src/list-response.ts · 변경 부분 8–14행',snippet:'이전: { items: null }\n변경: { items: [] }\n추가: 빈 목록 응답을 확인하는 테스트',confirmed:false,visibility:'private',mismatch:false,protected:false},
 {id:'c2',title:'날짜 입력 누락 검사 추가',fact:'날짜 입력이 없을 때 저장 전에 안내하도록 검사 조건을 추가했습니다.',contribution:'김가람의 커밋에서 날짜 유무 검사와 안내 문구 변경을 확인했습니다.',draft:'날짜를 입력하지 않은 경우 저장 전에 안내하도록 검사 조건을 추가했습니다.',evidence:'커밋 d4e5f6a',file:'src/date-input.ts · 변경 부분 21–26행',snippet:'추가: 날짜 입력 누락 검사\n안내: 날짜를 입력해 주세요.',confirmed:false,visibility:'private',mismatch:false,protected:false}
 ]};
 ui={states:{},tab:'catch',selectedRepo:'',currentCatch:'c1',detailReturn:'W03-R',resultReturn:'A-02',profileReturn:'H-01',recipientCatch:'c1',linkTitle:'',linkPassword:'',usePassword:false,recipientOverride:null,notesExtra:'',guide:false,linkFixtures:[]};
}
initial();
function currentCatch(){return data.catches.find(c=>c.id===ui.currentCatch)||data.catches[0]}
function activeLink(){return data.links.find(l=>l.id===data.currentLink)||ui.linkFixtures.find(l=>l.id===data.currentLink)||null}
function valid(l){return l&&l.status==='valid'&&Date.parse(l.expires)>demoTime().getTime()}
function demoTime(){return new Date('2026-09-22T06:00:00Z')}
function time(s){return new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(new Date(s))+' (KST)'}
function makeLink(title,password='',status='valid',id='link-'+(data.links.length+1)){
 const issued=status==='expired'?'2026-08-01T06:00:00Z':demoTime().toISOString();
 return {id,title,password,status,issued,expires:new Date(Date.parse(issued)+30*24*60*60*1000).toISOString()};
}
function exampleLinks(){return [makeLink('가상기업 지원','', 'valid','example-valid'),makeLink('이전 전달','', 'stopped','example-stopped'),makeLink('지난 검토','검토1234','expired','example-expired')]}
function mockURL(l){return 'https://example.invalid/share/'+(l?.id||'review-only')}
function nav(id,state){if(state)ui.states[id]=state;const hash=route(id,state);if(location.hash!==hash)history.pushState(null,'',hash);closeDialog();render();window.scrollTo(0,0)}
function stateTo(s){applyFixture(screen.id,s);ui.lastFixture=screen.id+':'+s;ui.states[screen.id]=s;history.replaceState(null,'',route(screen.id,s));render();$('#state-picker')?.focus()}
function toast(s){$('#toast').textContent=s;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),4500)}
function showDialog(title,content,actions){dialogReturn=document.activeElement;const d=$('#dialog');d.innerHTML=`<h2 id="dialog-title">${title}</h2>${content}<div class="actions">${actions}</div>`;d.showModal()}
function closeDialog(){const d=$('#dialog');if(d.open)d.close();if(dialogReturn?.isConnected)dialogReturn.focus()}
function fixtureCatch(s){
 const c=currentCatch();
 if(['unconfirmed','confirmed','public','hidden','mismatch','noDraft','saveError','protected'].includes(s)){
  c.confirmed=['confirmed','public','hidden'].includes(s);c.visibility=s==='public'?'public':s==='hidden'?'hidden':'private';c.mismatch=s==='mismatch';c.protected=s==='protected';
 }
 if(s==='noDraft')c.draft=null;
}
function applyFixture(id,s){
 ui.notesExtra='';
 if(id==='W04')fixtureCatch(s);
 if(id==='W05'){
  const c=currentCatch();c.confirmed=true;c.mismatch=false;c.protected=false;c.visibility=s==='public'?'public':'private';if(s==='noDraft')c.draft=null;
 }
 if(id==='W03-R'&&s==='noDraft')data.catches[1].draft=null;
 if(id==='A-01'&&s==='selected')ui.selectedRepo=data.repo;
 if(id==='L01'){
  if(s==='empty')data.catches.forEach(c=>c.visibility='private');
  if(s==='password'){ui.usePassword=true;ui.linkPassword='검토1234'}
  if(s==='duplicate'){ui.linkFixtures=[makeLink('가상기업 지원')];ui.linkTitle='  가상기업 지원  '}
  if(s==='limit')ui.linkFixtures=Array.from({length:5},(_,i)=>makeLink('검토 링크 '+(i+1),'','valid','limit-'+i));
  if(s==='normal')ui.linkFixtures=[];
 }
 if(id==='L03'&&s==='examples')ui.linkFixtures=exampleLinks();
 if(id==='L02'&&s==='password'){
  const l=makeLink('비밀번호 예시','검토1234','valid','password-example');ui.linkFixtures=[l];data.currentLink=l.id;
 }
 if(id.startsWith('V')){
  if(s!=='normal'){
   ui.recipientOverride=s;
   const l=makeLink('독립 수신자 상태 예시',s==='password'?'검토1234':'','valid','recipient-state');
   ui.linkFixtures=[l];data.currentLink=l.id;data.passwordOK.delete(l.id);
  }else ui.recipientOverride=null;
  if(id==='V01'&&!activeLink()){const l=makeLink('비밀번호 예시','검토1234','valid','password-example');ui.linkFixtures=[l];data.currentLink=l.id}
 }
}
function catalogue(){
 const groups=[...new Set(screens.map(s=>s.group))];
 $('#catalogue').innerHTML=`<nav><a href="#index" ${!screen?'aria-current="page"':''}>전체 화면 · 19</a><label class="mobile-select"><span class="visually-hidden">검토할 화면</span><select id="mobile-screen"><option value="index">전체 화면 목록</option>${screens.map(s=>`<option value="${s.id}" ${screen?.id===s.id?'selected':''}>${s.id} · ${s.name}</option>`).join('')}</select></label>${groups.map(g=>`<div class="nav-group"><h2>${g}</h2>${screens.filter(s=>s.group===g).map(s=>`<a href="#${s.id}" ${screen?.id===s.id?'aria-current="page"':''}><span class="code">${s.id}</span><span>${s.name.replace('비로그인 수신자 · ','').replace('로그인 직후 표시 이름 조회','이름 조회').replace('본인 근거 확인·Catch 상세','Catch 상세').replace('첫 방문·재방문 홈','홈')}</span></a>`).join('')}</div>`).join('')}</nav>`;
}
function indexPage(){return `<div class="intro"><div class="eyebrow">화면 검토 / 2026.09.22</div><h1>근거를 확인하고,<br>내가 선택한 Catch를 전달하기</h1><p class="muted">기존 화면 ID와 이동 관계를 유지한 클릭형 와이어프레임입니다. 화면을 고른 뒤 상단의 ‘검토할 상태’에서 예외를 비교하세요.</p><div class="actions">${btn('로그인부터 흐름 따라가기','restart',true)}${link('Catch 확인 화면부터','W04','unconfirmed')}${link('수신자 예외 보기','V02','stopped')}</div></div>
 <div class="flow-strip">${[['로그인·연동','W01'],['선택·분석 동의','A-01'],['접수·분석 상태','A-02'],['결과·근거 확인','W03-R'],['개별 공개','W05'],['링크 발행','L01'],['비로그인 열람','V02']].map(([t,id],i)=>`${i?'<span aria-hidden="true">→</span>':''}<a href="#${id}">${t}</a>`).join('')}</div>
 <div class="review-note"><strong>검토 주석 · 제품 화면 밖</strong><p>요구사항과 Rough Mockups에는 과거 승인 기록이 있습니다. Domain Design은 수정 후 최종 승인 대기까지 확인됐으며 단계 승인 기록은 없습니다. 이후 feasibility로 되돌린 기록이 있어 현재 단계 상태와 과거 승인을 동일하게 표시하지 않습니다. 작업 중 다른 세션이 feasibility를 승인하고 scope-definition으로 이동한 기록도 확인했습니다.</p><p>이 결과물은 담당자 상세 설계를 위한 검토본입니다. 공통 세션의 최종 확정·서비스 구현·실제 분석 성공을 뜻하지 않습니다.</p></div>
 <div class="screen-grid">${screens.map(s=>`<a class="screen-card" href="#${s.id}"><span class="code">${s.id}</span><strong>${s.name}</strong><p>${s.owner}</p><p>${Object.keys(s.states).length}개 상태 · ${Object.values(s.states).slice(0,3).join(' / ')}</p></a>`).join('')}</div>
 <section class="panel"><h2>담당자에게 이어갈 검토</h2><table class="source-table"><thead><tr><th>담당</th><th>화면·연결 확인</th></tr></thead><tbody><tr><td>팀원 2 · A/E</td><td>프로필 필수 항목·재인증 복귀, 대상 동의 안내, 접수·조회·반영 준비의 표현.</td></tr><tr><td>팀원 3 · C/D</td><td>분석 화면 배치·B 목록 복귀, 링크 상태·접근 거부·수신자 전용 헤더.</td></tr><tr><td>팀원 4 · B</td><td>작업 사실·기여·초안 구획, 확인·불일치·공개·숨김, 초안 없는 공개 표현.</td></tr><tr><td>팀원 1 · F/H/I</td><td>정상 0건·부분 실패·근거 한계의 의미, 질문 전달, 연결 차이 취합. 각 담당 설계 확정을 대행하지 않음.</td></tr></tbody></table></section>
 <details class="panel"><summary>출처·승인 상태·배치 차이</summary><p>필수 문서 6개와 wireframes.md에 연결된 고정 Git 판본 9개를 로컬에서 읽었습니다. 별도 이슈 댓글의 최신 수정 상태와 담당자 추가 합의는 확인하지 않았습니다.</p><table class="source-table"><tbody><tr><th>Rough Mockups</th><td>2026-09-21 23:45:06 KST · GATE_APPROVED 이력.</td></tr><tr><th>요구사항</th><td>2026-09-22 10:52:45 KST · GATE_APPROVED 이력.</td></tr><tr><th>Domain Design</th><td>2026-09-22 13:10:09 KST · 수정 후 승인 대기. Q1~Q8 사용자 결정 및 본인용 질문 보완을 화면 입력으로 사용.</td></tr><tr><th>최종 확인 상태</th><td>scope-definition / Running. 착수 때는 feasibility였으며, 다른 세션의 14:41:26 KST 승인·이동 기록을 확인했습니다. 이번 화면 작업에서는 명령·승인·상태 변경을 수행하지 않았습니다.</td></tr><tr><th>배치 제안</th><td>A-01~03을 자산에서 이어지는 별도 화면으로, 상세를 사실/초안과 근거/질문의 두 열로 배치. 작은 화면에서는 한 열. 일반 헤더는 로고·내 자산·공유 링크·프로필만 제공.</td></tr></tbody></table><p class="small">자세한 출처·지위·정책 미결·검증: <a href="README.md">README.md</a>. 원본 문서와 승인 이력은 팀 저장소를 확인해 주세요.</p></details>`}
function noteText(){
 const id=screen.id;let lines=[];
 if(['W01','W01-R','W02','W02-P'].includes(id))lines.push('A/E v0.10의 이름 조회·프로필 진입/복귀 구조를 재사용했습니다. 이름 필수 여부·길이와 상세 공개 항목 계약은 A/C/D 확인 대상이며 이 검토본에서 확정하지 않습니다.');
 if(id==='W02-G')lines.push('연결 해제·원본 재공개 영향은 정책 미결입니다. 이 검토본의 연결 버튼은 합성 상태만 바꿉니다.');
 if(id==='H-01')lines.push('로그인 후 자산 진입 구조를 재사용했습니다. 연결 후 홈은 기존 미채택 배치의 단순 이동 영역으로 제안하며 분석 상태·결과 집계를 넣지 않았습니다.');
 if(['W03','A-01','A-02','A-03','W03-R'].includes(id))lines.push('D/B 연결 제안: 분석 화면은 별도 본문으로 배치하고 자산의 GitHub 탭으로 돌아옵니다. 목록 → 상세 → 같은 목록 → 진입 출처를 유지합니다.');
 if(id==='A-01')lines.push('동의는 체크박스를 추가하지 않고 ‘동의하고 분석 요청’ 단일 행동으로 표현했습니다. 외부 AI 제공자·전송/보관 조건을 포함한 실제 동의 문구는 미확정이며 이 문구는 구조 검토용입니다.');
 if(id==='A-01'&&mode==='reanalysis'||id==='A-03')lines.push('정책 미결 — 과거 동의 재사용·재분석 허용·재요청 활성 조건. 재요청 실행은 연결하지 않고 기존 요청 중/접수/거절/불명 화면만 독립 상태로 비교합니다.');
 if(id==='A-02'&&['preparing','applicationFail'].includes(mode))lines.push('정책·계약 미결 — 결과 반영 복구 중 기존 작업 반환, 실패 확정·새 요청 허용 시점. 결과 준비 전 완료/결과 버튼을 제공하지 않습니다.');
 if(['A-02','W03-R'].includes(id)&&['partial','draftFail','noDraft'].includes(mode))lines.push('Domain Design Q3~Q5 사용자 결정 적용: 실패 영향과 독립적으로 기준 충족이 확인된 Catch만 제공. 초안 생성 실패를 정상 0건으로 표시하지 않습니다. 단계 전체 승인과 구분합니다.');
 if(['W04','W05'].includes(id)){
  lines.push('B/F 연결 제안: 확인된 작업 사실·본인 기여, 원본 근거, 생성 설명을 분리했습니다. 최소 질문은 본인만 보며 답변 입력·저장은 없습니다.');
  if(!currentCatch().draft)lines.push('정책 미결 — 실패 후 초안 보완. 보완·재생성 버튼 없이 초안 없는 등록/확인/개별 공개 경로를 검토합니다.');
  if(['hidden','mismatch','protected'].includes(mode)||currentCatch().mismatch||currentCatch().visibility==='hidden')lines.push('정책 미결 — 불일치 취소·재공개, 원본 재공개·본인 보관/복구의 상세 조건. 일반 확인 버튼으로 복구하지 않습니다.');
 }
 if(['L01','L02','L03'].includes(id))lines.push('C 초안 재사용: 제목은 발행자만 표시, 앞뒤 공백 제외 유효 제목 중복 금지, 유효 링크 최대 5개, 30일 고정 만료. 중단·만료는 수신자에게 같은 접근 불가 문구를 사용합니다.');
 if(id==='W05'&&mode==='afterLink')lines.push('정책 미결 — 발행 후 새 공개 Catch·재분석 결과·본문 변화의 기존 링크 영향. 이 검토본은 해당 편입/교체 분기를 실행하지 않습니다. 기존 공개 Catch의 숨김과 현재 공개 프로필 반영은 확인할 수 있습니다.');
 if(id==='V01')lines.push('비밀번호 예시: 검토1234. 사용자 지정 링크에서는 발행할 때 입력한 값을 사용합니다. 실제 비밀번호 보호가 아닌 화면 분기이며 링크 거부가 인증보다 우선합니다.');
 if(id.startsWith('V'))lines.push('수신자 전용 헤더와 읽기 전용 본문입니다. 링크 관리 제목·본인용 질문·내부 오류를 표시하지 않습니다. 상태 선택은 독립 화면 예시이며 실제 접근 통제가 아닙니다.');
 if(ui.notesExtra)lines.unshift(ui.notesExtra);
 return `<aside class="review-note" aria-label="검토 주석"><strong>검토 주석 · ${screen.owner} · 제품 화면 밖</strong>${lines.map(t=>`<p>${t}</p>`).join('')}</aside>`;
}
function shell(content){
 const recipient=screen.id.startsWith('V'),auth=['W01','W01-R'].includes(screen.id);
 const navContent=recipient?'':auth?btn('로그아웃','logout'): `<a href="#W03" ${['W03','A-01','A-02','A-03','W03-R','W04','W05'].includes(screen.id)?'aria-current="page"':''}>내 자산</a><a href="#L03" ${screen.id.startsWith('L')?'aria-current="page"':''}>공유 링크</a>${btn('프로필','profile')}`;
 return `<section class="product" aria-label="제품 화면 예시"><header class="product-header">${recipient?'<span class="product-brand">CatchU</span>':'<a class="product-brand" href="#H-01">CatchU</a>'}<nav class="product-nav" aria-label="서비스 탐색">${screen.id==='W01'?'':navContent}</nav></header><div class="product-body" id="product-content">${content}</div><div class="footer-note">합성 자료 · 화면과 행동 검토를 위한 예시</div></section>`;
}
function render(){
 const raw=location.hash.slice(1)||'index';const [id,query]=raw.split('?');screen=byId[id];ui.notesExtra='';
 if(!screen){catalogue();$('#workspace').innerHTML=indexPage();document.title='CatchU · 화면 목록';return}
 const requested=new URLSearchParams(query).get('state');
 mode=(requested&&screen.states[requested]?requested:ui.states[id])||Object.keys(screen.states)[0];ui.states[id]=mode;
 // Direct links are explicit fixture entry points; apply only once per destination key.
 const fixtureKey=id+':'+mode;
 if(requested&&ui.lastFixture!==fixtureKey){applyFixture(id,mode);ui.lastFixture=fixtureKey}
 catalogue();document.title=`${id} ${screen.name} · CatchU 화면 검토`;
 const nextExample=id==='A-02'&&!['complete','partial','draftFail','zero','insufficient'].includes(mode)?btn('결과 준비 완료 예시로 전환','demo-complete'):'';
 $('#workspace').innerHTML=`<div class="review-toolbar"><div class="review-title"><div class="eyebrow">${screen.group} / ${id}</div><h1>${screen.name}</h1><div class="review-meta">${screen.owner} · 배치·문구 검토 제안</div></div><label class="state-control"><span>검토할 상태 · 제품 기능 아님</span><select id="state-picker">${Object.entries(screen.states).map(([k,v])=>`<option value="${k}" ${mode===k?'selected':''}>${v}</option>`).join('')}</select></label></div>${ui.guide?`<div class="review-step small"><strong>흐름 따라가기</strong><span>${guideText(id)}</span>${nextExample}</div>`:nextExample?`<div class="review-step small"><span>분석은 실행하지 않습니다.</span>${nextExample}</div>`:''}${shell(productContent())}${noteText()}`;
 if(id==='W02-P'&&mode==='modal'&&!$('#dialog').open)openProfile();
}
function guideText(id){return ({W01:'Google로 계속하기 → 기본 프로필',W02:'프로필 저장 → 미연동 홈','H-01':'GitHub 연결 → 내 자산 GitHub 탭','W02-G':'연동은 분석 동의와 별개입니다.',W03:'GitHub 탭 → 저장소 선택', 'A-01':'대상을 선택하고 동의·요청 버튼을 누르세요.','A-02':'접수와 완료를 비교한 뒤 검토 도구로 결과 예시를 여세요.','W03-R':'상세 확인 → 근거 확인','W04':'명시적으로 확인 완료 → 별도 공개 선택',W05:'지금 공개 또는 미공개 유지',L01:'제목·선택 비밀번호 → 발행',L02:'수신자 화면 열기 → 공개 자료',V02:'상세 보기 → 공개 자료 목록으로'})[id]||'상단 상태 선택으로 예외를 비교할 수 있습니다.'}
function profileCard(){return `<div class="profile-display"><div class="profile-placeholder" aria-hidden="true">○</div><div><h2>${esc(data.profile.name)}</h2><p>${esc(data.profile.intro)}</p><p class="small">${esc(data.profile.role)} · ${esc(data.profile.tech)} <span class="muted">— 직접 입력한 정보</span></p><p class="small muted">GitHub · sample-garam</p></div></div>`}
function productContent(){
 switch(screen.id){
 case 'W01':return `<div class="narrow"><div class="eyebrow">시작하기</div><h1>내 작업을 근거와 함께<br>정리하고 전달하세요.</h1><p class="muted">GitHub 기록에서 경험을 살펴보고, 확인한 자료를 직접 선택해 공개할 수 있습니다.</p>${mode==='cancel'?notice('로그인을 취소했습니다.'):mode==='error'?err('로그인하지 못했습니다. 다시 시도해 주세요.'):mode==='expired'?notice('로그인이 만료되었습니다.','다시 로그인한 후 요청 상태를 확인해 주세요.'):''}<div class="actions">${btn('Google로 계속하기','login',true)}</div><p class="small muted">로그인 후 GitHub 계정을 별도로 연결합니다.</p></div>`;
 case 'W01-R':return `<div class="narrow"><h1>프로필 확인</h1>${mode==='loading'?notice('프로필을 불러오는 중입니다.'):mode==='error'?err('로그인은 완료됐지만 프로필을 불러오지 못했습니다. 표시 이름 저장 여부를 확인한 뒤 계속할 수 있습니다.'):notice(mode==='missing'?'저장된 표시 이름이 없습니다.':'프로필을 확인했습니다.')}<div class="actions">${mode==='loading'?btn('불러오는 중','none',false,true):mode==='error'?btn('다시 불러오기','profile-reload',true):mode==='missing'?link('프로필 입력','W02','normal',true):link('홈으로','H-01','unlinked',true)}</div></div>`;
 case 'W02':return profileForm();
 case 'W02-P':return `${back('돌아가기',ui.profileReturn)}<h1>내 프로필</h1>${mode==='loading'?notice('프로필을 불러오는 중입니다.'):mode==='error'?err('프로필을 불러오지 못했습니다.'):`<div class="box">${profileCard()}</div>`}<div class="actions">${mode==='error'?btn('다시 불러오기','reload',true):link('프로필 수정','W02','edit',true)}${link('GitHub 연결 상태','W02-G',data.linked?'connected':'normal')}</div>`;
 case 'W02-G':return githubPage();
 case 'H-01':return homePage();
 case 'W03':return assetsPage();
 case 'A-01':return selectionPage();
 case 'A-02':return analysisPage();
 case 'A-03':return failurePage();
 case 'W03-R':return resultsPage();
 case 'W04':return catchPage();
 case 'W05':return publishPage();
 case 'L01':return issuePage();
 case 'L02':return issuedPage();
 case 'L03':return linksPage();
 case 'V01':return passwordPage();
 case 'V02':return recipientList();
 case 'V03':return recipientDetail();
 }
}
function profileForm(){const edit=mode==='edit',p=ui.profileDraft||data.profile;
 return `<div class="narrow"><h1>${edit?'프로필 수정':'기본 프로필'}</h1><p>나를 소개할 정보를 확인해 주세요.</p>${mode==='loadError'?err('프로필을 불러오지 못했습니다.'):`<form id="profile-form" class="stack"><label><span>표시 이름</span><input name="name" value="${esc(p.name)}" autocomplete="off"></label><label><span>한 줄 소개</span><input name="intro" value="${esc(p.intro)}"></label><label><span>직무</span><input name="role" value="${esc(p.role)}"></label><label><span>기술 스택</span><input name="tech" value="${esc(p.tech)}"></label><p class="small muted">직무·기술 스택은 직접 입력한 정보입니다. GitHub 연동 없이 홈을 이용할 수 있습니다.</p>${edit?notice('프로필 수정은 기존 공유 링크의 다음 조회에도 반영됩니다.'):''}${mode==='error'?err('프로필을 저장하지 못했습니다. 입력 내용을 유지했습니다.'):mode==='unknown'?notice('저장 여부를 확인하지 못했습니다.','저장된 프로필을 먼저 확인해 주세요.'):''}<div class="actions">${edit?btn('취소','profile-cancel'):''}${mode==='unknown'?btn('저장된 프로필 확인','profile-reload',true):btn(mode==='saving'?'저장하는 중…':edit?'저장':'저장하고 홈으로','profile-save',true,mode==='saving')}</div></form>`}${mode==='loadError'?btn('다시 불러오기','reload',true):''}</div>`}
function githubPage(){return `${back('돌아가기',ui.profileReturn)}<div class="narrow"><h1>GitHub 연결</h1><p>분석할 저장소를 선택하려면 GitHub 계정을 연결해 주세요.</p><div class="box">${badges(mode==='connected'?'GitHub 연동됨':'GitHub 미연동')}<p>연동만으로 분석이 시작되거나 Catch가 공개되지 않습니다.</p>${mode==='connected'?'<p>연결 계정 · sample-garam</p>':''}${mode==='cancel'?notice('GitHub 연결을 취소했습니다.'):mode==='error'?err('GitHub 계정을 연결하지 못했습니다.'):mode==='unknown'?notice('연결 상태를 확인하지 못했습니다.'):''}<div class="actions">${mode==='connected'?btn('내 자산 GitHub 탭으로','github-tab',true):mode==='unknown'?btn('상태 다시 확인','reload',true):btn(mode==='loading'?'연결하는 중…':'GitHub 연결','connect',true,mode==='loading')}</div></div></div>`}
function homePage(){const guest=mode==='normal'&&!data.logged;
 return `<div class="narrow"><div class="eyebrow">내 기록에서 시작하는 경험</div><h1>${guest?'작업의 흔적을<br>설명할 수 있는 경험으로.':`${esc(data.profile.name)}님, 안녕하세요.`}</h1><p>기록을 살펴보고 근거를 확인한 뒤, 공유할 Catch를 선택하세요.</p>${guest?`<div class="box soft"><h2>어떤 자료를 정리하나요?</h2><p class="small">가상 예시 · 빈 목록 응답 형식 정리</p><p>작업 사실 → 연결된 근거 → 설명 초안 → 나의 확인</p></div><div class="actions">${link('Google로 시작하기','W01','normal',true)}</div>`:mode==='error'?`${err('연결 상태를 불러오지 못했습니다. 연결이 없다는 뜻은 아닙니다.')}${btn('다시 불러오기','reload',true)}`:mode==='unlinked'||(!data.linked&&mode!=='ready'&&mode!=='linked')?`<div class="box"><h2>1. GitHub 계정 연결</h2><p>연결한 뒤 내 자산에서 분석할 저장소를 선택합니다.</p>${link('GitHub 연결','W02-G','normal',true)}</div>${link('내 자산으로','W03')}`:`<div class="box"><h2>내 자산에서 이어서 확인하세요.</h2><p>GitHub 탭에서 저장소를 선택하고 요청한 분석을 확인할 수 있습니다.</p>${btn('내 자산으로','github-tab',true)}</div><div class="actions">${link('공유 링크 관리','L03')}</div>`}</div>`}
function catchBadges(c){return badges(c.confirmed?'확인 완료':'확인 전',c.visibility==='public'?'공개':c.visibility==='hidden'?'숨김':'미공개',...(c.mismatch?['불일치 표시 있음']:[]),...(!c.draft?['설명 초안 없음']:[]))}
function catchRow(c,recipient=false){return `<article class="list-row"><div><h2>${esc(c.title)}</h2>${recipient?`<p class="small muted">작업 사실 · 본인 기여 · 연결 근거${c.draft?' · 설명':''}</p>`:catchBadges(c)}</div>${btn(recipient?'상세 보기':'상세 확인',recipient?'recipient-catch':'open-catch',false,false,`data-id="${c.id}"`)}</article>`}
function assetsPage(){let content='';
 if(mode==='denied')content=notice('이 자료를 열람할 수 없습니다.');
 else if(mode==='loading')content=notice(`${ui.tab==='github'?'분석 이력':'Catch'}을 불러오는 중입니다.`);
 else if(mode==='error')content=err(`${ui.tab==='github'?'분석 이력':'Catch'}을 불러오지 못했습니다.`)+btn('다시 불러오기','reload');
 else if(ui.tab==='github'){
  content=`<div class="heading-row"><div><h2>GitHub 분석 이력</h2><p class="muted small">요청한 분석의 상태와 결과를 확인합니다.</p></div>${mode==='unlinked'?link('GitHub 연결','W02-G','normal',true):link('저장소 선택','A-01','normal',true)}</div>`;
  if(mode==='unlinked')content+=notice('GitHub 계정을 연결해 주세요.','연동 후 저장소를 선택하고 분석에 동의할 수 있습니다.');
  else if(mode==='empty'||!data.requested&&mode!=='history')content+=empty('아직 분석 이력이 없습니다.','저장소를 선택하고 분석을 요청해 보세요.');
  else if(mode==='history')content+=`<div class="list">${[['진행 중','A-02','running','진행 상태 보기'],['결과 준비 완료','W03-R','normal','결과 확인'],['분석 실패','A-03','normal','실패 내용 보기'],['정상 완료 · 검토할 Catch 없음','A-02','zero','상태 보기']].map(([t,id,s,a],i)=>`<div class="list-row"><div><h3>sample-lab/record-board · 분석 예시 ${i+1}</h3><p>${t}</p></div>${id==='W03-R'?btn(a,'history-results'):link(a,id,s)}</div>`).join('')}</div>`;
  else content+=`<div class="list-row"><div><h3>${esc(data.repo)}</h3><p>${byId['A-02'].states[data.analysis]||'접수 확인'}</p><p class="small muted">요청: 2026-09-22 15:00 KST</p></div>${['complete','partial','draftFail'].includes(data.analysis)?btn('결과 확인','history-results',true):link('상태 보기','A-02',data.analysis)}</div>`;
 }else content=mode==='empty'?empty('아직 확인할 Catch가 없습니다.','GitHub 탭에서 저장소를 선택할 수 있습니다.',btn('GitHub 탭으로','github-tab')):`<p class="small muted">공개·숨김은 기존 공유 링크의 다음 열람에도 적용됩니다.</p><div class="list">${data.catches.map(c=>catchRow(c)).join('')}</div>`;
 return `<div class="heading-row"><h1>내 자산</h1>${link('링크 발행으로','L01')}</div><div class="tabs" aria-label="자산 구분">${btn('내 Catch','tab-catch',false,false,`aria-pressed="${ui.tab==='catch'}"`)}${btn('GitHub','tab-github',false,false,`aria-pressed="${ui.tab==='github'}"`)}</div>${content}`}
function selectionPage(){
 const base=`${back('내 자산 · GitHub', 'W03')}<h1>저장소 선택·분석 동의</h1><p class="muted">선정된 공개 저장소에서 분석할 대상을 선택하세요.</p>`;
 const states={empty:['현재 선택할 수 있는 저장소가 없습니다.','선정 목록을 확인한 결과입니다.'],loading:['선정 저장소를 불러오는 중입니다.',''],error:['저장소 목록을 불러오지 못했습니다.','저장소가 없는 상태와 다릅니다.'],denied:['이 저장소를 분석할 수 없습니다.','선정 대상과 현재 접근 조건을 확인해 주세요.'],sending:['분석을 요청하는 중입니다.','접수 결과를 기다리고 있습니다.'],accepted:['분석 요청이 접수되었습니다.','접수는 분석 시작이나 완료를 뜻하지 않습니다.'],unknown:['요청 접수 여부를 확인하지 못했습니다.','다시 제출하지 말고 요청 상태를 확인해 주세요.'],duplicate:['이 저장소의 분석이 진행 중입니다.','기존 작업의 상태를 확인해 주세요.'],reanalysis:['이 저장소에는 이전 분석 이력이 있습니다.','이전 분석 상태와 결과를 확인할 수 있습니다.']};
 if(states[mode]){const [t,p]=states[mode];return base+notice(t,p)+`<div class="actions">${mode==='accepted'?link('진행 상태 보기','A-02','accepted',true):mode==='unknown'?btn('요청 상태 확인','request-check',true):mode==='duplicate'?link('기존 분석 상태 보기','A-02','running',true):mode==='reanalysis'?link('이전 분석 보기','A-02','complete'):['error','empty','denied'].includes(mode)?btn('목록 다시 불러오기','reload',true):btn('처리 중','none',false,true)}${btn('GitHub 탭으로','github-tab')}</div>`}
 return base+`<div class="two-col"><section><h2>선정 저장소</h2>${['sample-lab/record-board','sample-lab/task-notes'].map((repo,i)=>`<label class="repo"><input type="radio" name="repo" value="${repo}" ${ui.selectedRepo===repo?'checked':''}><span><strong>${repo}</strong><span class="small muted">공개 저장소 · 합성 예시 ${i+1}</span></span></label>`).join('')}<div class="repo"><div><strong>sample-lab/pending-work</strong><span class="small muted">분석 진행 중</span></div>${link('상태 보기','A-02','running')}</div></section><section class="box soft"><h2>선택한 저장소의 분석 동의</h2>${ui.selectedRepo?`<p><strong>${esc(ui.selectedRepo)}</strong></p><ul><li>선택한 저장소의 작업 기록과 변경 내용을 분석합니다.</li><li>경험 후보·근거와 설명 초안을 준비합니다.</li><li>설명 생성 과정에서 필요한 자료를 외부 AI로 처리할 수 있습니다.</li><li>결과는 미공개이며 확인 후 별도로 공개를 선택합니다.</li></ul><div class="actions">${btn('동의하고 분석 요청','request',true)}</div>`:'<p>저장소를 선택하면 해당 대상의 안내를 확인할 수 있습니다.</p>'+btn('동의하고 분석 요청','request',true,true)}</section></div><div class="actions">${btn('취소','github-tab')}</div>`;
}
function analysisPage(){
 const stateInfo={accepted:['요청 접수','분석 요청이 접수되었습니다. 시작 여부는 아직 확인되지 않았습니다.',0],queued:['분석 대기','분석을 시작하기 위해 대기하고 있습니다.',1],running:['분석 진행 중','선택한 저장소의 기록을 분석하고 있습니다.',1],preparing:['결과 준비 중','분석한 자료를 확인할 수 있도록 준비하고 있습니다.',2],complete:['분석 완료','결과를 확인할 수 있습니다. Catch는 아직 미공개입니다.',3],zero:['분석 완료','오류 없이 분석했으나 등록 기준에 맞는 후보가 없어, 이번 분석에서 검토할 Catch가 없습니다.',3],insufficient:['분석 완료 · 등록할 Catch 없음','작업 사실이나 본인 기여를 뒷받침할 근거가 충분하지 않아 등록 기준을 충족한 후보가 없습니다. 분석 오류와는 구분됩니다.',3],partial:['일부 분석에 실패했습니다.','실패한 부분과 독립적으로 근거·기여를 확인할 수 있는 Catch만 제공합니다. 전체 분석 성공이 아닙니다.',3],draftFail:['설명 초안을 만들지 못했습니다.','근거·기여와 다른 등록 기준을 충족한 Catch는 미공개로 준비되었습니다. 설명 초안 없이 근거를 확인할 수 있습니다.',3],collectionFail:['자료 수집에 실패했습니다.','이번 분석의 결과를 준비하지 못했습니다. 기존 자료와 링크는 유지됩니다.',1],generationFail:['분석 처리에 실패했습니다.','이번 후보의 등록 기준 충족 여부를 확인하지 못했습니다. 후보 0건으로 판정한 결과가 아닙니다.',1],applicationFail:['결과 준비를 확인하지 못했습니다.','Catch를 열람할 수 있는지 확인되지 않았습니다. 분석 완료로 표시하지 않습니다.',2],error:['분석 상태를 불러오지 못했습니다.','마지막 확인: 분석 진행 중 · 15:00 KST. 최신 상태는 확인되지 않았으며 분석 실패를 뜻하지 않습니다.',-1],unknown:['요청 접수 여부를 확인하지 못했습니다.','새 요청을 보내지 않고 기존 요청 상태를 확인합니다.',-1],expired:['로그인이 만료되었습니다.','다시 로그인해 요청 상태를 확인해 주세요.',-1]};
 const [title,text,step]=stateInfo[mode]||stateInfo.accepted;
 return `${back('내 자산 · GitHub','W03')}<h1>분석 상태</h1>${mode==='expired'?notice(title,text)+link('로그인으로','W01','expired',true):`<div class="box"><p class="small muted">분석 대상</p><h2>${esc(data.repo)}</h2><ol class="steps">${['요청 접수','분석','결과 준비','열람 가능'].map((t,i)=>`<li class="${i===step?'current':i<step?'done':''}">${i+1}. ${t}</li>`).join('')}</ol>${notice(title,text)}<div class="actions">${['complete','partial','draftFail'].includes(mode)?btn(mode==='partial'?'유효한 결과 확인':'결과 확인','analysis-results',true):['collectionFail','generationFail'].includes(mode)?link('실패 내용 보기','A-03','normal',true):['zero','insufficient'].includes(mode)?'':btn(mode==='unknown'?'요청 상태 확인':'상태 다시 불러오기','status-check',true)}${btn('내 자산으로','github-tab')}</div></div><p class="small muted">이 화면을 나가도 요청이 취소되지 않습니다. 내 자산의 GitHub 탭에서 다시 확인할 수 있습니다.</p>`}`;
}
function failurePage(){const content={normal:['분석에 실패했습니다.','분석에 필요한 자료를 처리하지 못했습니다.'],partial:['일부 분석에 실패했습니다.','실패 영향과 독립적으로 유효한 결과만 확인할 수 있습니다.'],error:['분석 상태를 불러오지 못했습니다.','분석 실패 여부는 확인되지 않았습니다.'],retry:['이전 분석이 실패했습니다.','기존 요청의 상태와 결과를 확인해 주세요.'],sending:['다시 분석을 요청하는 중입니다.','접수 여부를 확인하고 있습니다.'],accepted:['분석 재요청이 접수되었습니다.','접수만으로 시작·완료를 뜻하지 않습니다.'],rejected:['지금은 다시 분석을 요청할 수 없습니다.','현재 요청 조건을 충족하지 않습니다.'],unknown:['요청 접수 여부를 확인하지 못했습니다.','자동으로 다시 제출하지 않습니다.']}[mode];
 return `${back('내 자산 · GitHub','W03')}<h1>실패·재요청</h1><div class="box"><h2>${esc(data.repo)}</h2>${notice(...content)}<p>기존 Catch와 공유 링크는 유지됩니다.</p><div class="actions">${mode==='partial'?btn('유효한 결과 확인','partial-results',true):mode==='accepted'?link('진행 상태 보기','A-02','accepted',true):mode==='unknown'?btn('요청 상태 확인','request-check',true):mode==='error'?btn('상태 다시 불러오기','status-check',true):mode==='sending'?btn('요청 중','none',false,true):btn('다시 분석 요청','policy-retry',false,true)}${btn('GitHub 탭으로','github-tab')}</div></div>`;
}
function resultsPage(){let content;
 if(mode==='loading')content=notice('분석 결과를 불러오는 중입니다.');else if(mode==='error')content=err('분석 결과를 불러오지 못했습니다. 결과가 없는 상태와 다릅니다.')+btn('다시 불러오기','reload',true);else if(mode==='denied')content=notice('이 분석 결과를 열람할 수 없습니다.');else if(mode==='zero')content=empty('이번 분석에서 검토할 Catch가 없습니다.','오류 없이 분석했지만 등록 기준을 충족한 후보가 없습니다.');else content=`${mode==='partial'?notice('일부 분석 실패','실패의 영향과 분리해 등록 기준 충족을 확인한 Catch만 아래에 표시합니다.'):mode==='noDraft'?notice('설명 초안 생성에 실패한 Catch가 있습니다.','근거·기여와 설명 초안의 상태를 나누어 확인해 주세요.'):''}<div class="list">${data.catches.slice(0,mode==='single'||mode==='partial'?1:2).map(c=>catchRow(c)).join('')}</div>`;
 return `${back(ui.resultReturn==='W03'?'분석 이력으로':'분석 상태로',ui.resultReturn)}<h1>분석 결과</h1><p>${esc(data.repo)} · 2026-09-22 요청</p><p class="muted small">목록·상세를 여는 것만으로 확인되거나 공개되지 않습니다.</p>${content}`}
function evidence(c){return `<section class="box"><h2>원본 근거</h2><p class="small"><strong>${esc(c.evidence)}</strong></p><p class="small muted">${esc(c.file)}</p><div class="evidence"><p>합성 원문 발췌</p><pre>${esc(c.snippet)}</pre></div><p class="small muted">관련 변경 부분만 표시합니다. 저장소 전체나 모든 기여자의 작업을 설명하지 않습니다.</p>${btn('근거 원문 보기','evidence',false,false,`data-id="${c.id}"`)}</section>`}
function factDraft(c,recipient=false){return `<section class="box"><h2>근거로 확인한 작업 사실</h2><p>${esc(c.fact)}</p><h3>본인 기여</h3><p>${esc(c.contribution)}</p><p class="small muted">연결 근거: ${esc(c.evidence)}</p></section><section class="box soft"><h2>${recipient?'생성된 설명':'자동 생성 설명 초안'}</h2>${c.draft?`<p>${esc(c.draft)}</p><p class="small muted">위 근거를 바탕으로 만든 설명입니다.</p>`:`<p>${recipient?'제공된 설명이 없습니다. 위의 작업 사실·본인 기여와 근거를 확인할 수 있습니다.':'설명 초안을 만들지 못했습니다. 근거·기여가 확인된 Catch로 등록되었으며 다른 공개 조건을 충족하면 확인 후 별도로 공개할 수 있습니다.'}</p>`}</section><section class="box"><h2>기록에서 확인할 수 없는 것</h2><p>작업을 선택한 동기, 의사결정 과정과 적용 후 성과는 제공된 기록에서 확인할 수 없습니다.</p></section>`}
function catchPage(){const c=currentCatch();const b=back(ui.detailReturn==='W03-R'?'결과 목록으로':'내 자산으로',ui.detailReturn);
 if(mode==='error')return b+'<h1>Catch 상세</h1>'+err('Catch를 불러오지 못했습니다.')+btn('다시 불러오기','reload',true);
 if(mode==='denied')return b+notice('이 Catch를 열람할 수 없습니다.');
 if(c.protected||mode==='protected')return b+'<h1>Catch 공개 보호</h1>'+notice('원본 저장소의 비공개 전환이 확인되었습니다.','관련 Catch는 기존 링크에서도 열람할 수 없습니다. 원본 상태를 확인해 주세요.');
 return `${b}<h1>${esc(c.title)}</h1>${catchBadges(c)}${mode==='sourceError'?err('근거 원문에 일시적으로 접근하지 못했습니다. 원본이 비공개로 바뀌었다고 판단한 것은 아닙니다.'):''}<div class="two-col"><div class="detail-col">${factDraft(c)}</div><div class="detail-col">${evidence(c)}<section class="box"><h2>생각해볼 질문</h2><p class="small muted">나의 경험을 되짚기 위한 질문</p><p class="question">이 변경을 하기 전 어떤 동작을 확인했나요?</p><p class="question">이 기록에서 직접 설명할 수 있는 나의 기여는 무엇인가요?</p><p class="small muted">본인에게만 표시됩니다. 질문에 답변을 입력하거나 저장하지 않습니다.</p></section></div></div>${c.mismatch?notice('불일치 표시가 있습니다.','현재는 미공개입니다. 불일치 표시가 설명 수정이나 재생성 완료를 뜻하지 않습니다.'):c.visibility==='hidden'?notice('숨김 상태입니다.','이 Catch는 기존 공유 링크의 다음 열람에서도 제외됩니다.'):''}${mode==='saveError'?err('확인 내용을 저장하지 못했습니다. 확인·공개 상태는 바뀌지 않았습니다.'):''}<div class="box"><p>근거와 본인 기여를 확인한 뒤 선택해 주세요. 설명 문구는 직접 수정할 수 없습니다.</p><div class="actions">${c.mismatch||c.visibility==='hidden'?'':c.visibility==='public'?btn('숨기기','hide'):c.confirmed?btn('공개 선택','choose-public',true):btn('확인 완료','confirm',true)}${!c.mismatch&&c.visibility!=='hidden'?btn('불일치 표시','mismatch'):''}${link('목록으로',ui.detailReturn)}</div></div>`}
function publishPage(){const c=currentCatch();
 if(c.visibility==='public'||mode==='public')return `<div class="narrow"><h1>공개 상태입니다.</h1><p>${esc(c.title)}</p>${notice('공개 선택이 반영되었습니다.','유효한 공유 링크에서 현재 허용된 자료를 열람할 수 있습니다.')}<div class="actions">${link('링크 발행으로','L01',undefined,true)}${link('Catch 상세로','W04','normal')}</div></div>`;
 return `<div class="narrow"><h1>Catch 확인을 완료했습니다.</h1><p>${esc(c.title)}</p>${badges('확인 완료','미공개',...(!c.draft?['설명 초안 없음']:[]))}<div class="box"><p>현재는 미공개입니다. 확인 완료만으로 공개되지 않습니다.</p><p>공개하면 유효한 공유 링크에서 근거와 본인 기여${c.draft?', 설명':''}를 열람할 수 있습니다.</p>${!c.draft?notice('설명 초안 없이도 공개할 수 있습니다.','다른 공개 조건을 충족하고 근거·본인 기여를 확인한 Catch입니다.'):''}${mode==='error'?err('공개 상태를 저장하지 못했습니다. 현재는 미공개입니다.'):''}<div class="actions">${btn(mode==='saving'?'공개 상태 저장 중…':'지금 공개','publish',true,mode==='saving'||mode==='afterLink')}${btn('미공개 유지','keep-private')}</div></div>${back('Catch 상세로','W04','normal')}</div>`}
function publicCatches(){return data.catches.filter(c=>c.visibility==='public'&&!c.protected&&!c.mismatch)}
function issuePage(){const allLinks=[...data.links,...ui.linkFixtures];const n=allLinks.filter(valid).length;const busy=['loading','error','sending'].includes(mode);
 return `${back('공유 링크 관리로','L03')}<h1>공유 링크 발행</h1><div class="two-col"><section><h2>현재 공개 자료</h2>${mode==='loading'?notice('공개 자료를 불러오는 중입니다.'):mode==='error'?err('공개 자료를 불러오지 못했습니다. 자료가 0개라는 뜻은 아닙니다.')+btn('자료 다시 불러오기','reload'): `<div class="box">${profileCard()}<hr><h3>공개 GitHub 자산</h3>${publicCatches().length?publicCatches().map(c=>`<p>${esc(c.title)}</p>`).join(''):'<p>현재 공개된 GitHub 자산이 없습니다. 프로필만으로도 링크를 발행할 수 있습니다.</p>'}<div class="actions">${link('내 자산에서 확인','W03')}</div></div>`}<p class="small muted">프로필 수정과 Catch 숨김은 기존 공유 링크의 다음 열람에도 반영됩니다.</p></section><section class="box"><form id="link-form" class="stack"><h2>링크 설정</h2><label><span>링크 제목 <span class="small">(필수)</span></span><input name="title" value="${esc(ui.linkTitle)}" placeholder="예: 가상기업 지원" ${busy?'disabled':''}></label><p class="small muted">나에게만 보이는 관리용 제목입니다. 앞뒤 공백을 제외하고 같은 제목의 유효 링크를 중복 발행할 수 없습니다.</p><p>현재 유효 링크 <strong>${n} / 5개</strong><br><span class="small muted">중단·만료 링크는 한도에서 제외됩니다.</span></p><label class="check"><input id="use-password" type="checkbox" ${ui.usePassword?'checked':''} ${busy?'disabled':''}><span>비밀번호 사용 (선택)</span></label>${ui.usePassword?`<label><span>링크 비밀번호</span><input name="password" type="password" value="${esc(ui.linkPassword)}" autocomplete="off" ${busy?'disabled':''}></label>${btn('비밀번호 보기','show-password',false,busy)}`:''}<p><strong>유효기간 · 발행 시점부터 30일</strong></p>${mode==='duplicate'?notice('같은 제목의 유효한 링크가 이미 있습니다.','공유 링크 관리에서 제목과 상태를 확인해 주세요.'):mode==='limit'?notice('유효 링크는 최대 5개입니다.','사용하지 않는 링크를 중단한 뒤 발행해 주세요.'):mode==='failed'?err('링크를 발행하지 못했습니다.'):mode==='unknown'?notice('발행 여부를 확인하지 못했습니다.','같은 제목으로 다시 발행하면 기존 유효 링크 여부를 확인할 수 있습니다.'):''}<div id="link-validation" aria-live="polite"></div><div class="actions">${btn(mode==='sending'?'링크를 발행하는 중…':mode==='unknown'?'같은 제목으로 다시 발행':'링크 발행','issue',true,busy||mode==='limit')}${link('공유 링크 관리로','L03')}</div></form></section></div>`}
function issuedPage(){let l=activeLink();if(!l){l=makeLink('가상기업 지원');ui.linkFixtures=[l];data.currentLink=l.id}
 return `<div class="narrow"><h1>링크가 발행되었습니다.</h1><div class="box"><h2>${esc(l.title)}</h2><p class="small muted">나에게만 표시되는 제목</p><code class="link-url">${esc(mockURL(l))}</code><dl class="fact-list"><dt>발행</dt><dd>${time(l.issued)}</dd><dt>만료</dt><dd>${time(l.expires)}</dd><dt>비밀번호</dt><dd>${l.password?'설정됨':'없음'}</dd></dl>${mode==='copyError'?err('URL을 복사하지 못했습니다. 주소를 직접 선택해 복사할 수 있습니다.'):''}<div class="actions">${btn('URL 복사','copy',true)}${btn('수신자 화면 열기','open-recipient')}</div><p class="small muted">${l.password?'비밀번호를 설정했다면 비밀번호도 수신자에게 전달하세요.':''}</p></div>${link('공유 링크 관리','L03')}</div>`}
function linksPage(){let links=mode==='examples'?ui.linkFixtures:[...data.links,...ui.linkFixtures];if(mode==='examples'&&!links.length)links=ui.linkFixtures=exampleLinks();
 const heading=`<div class="heading-row"><div><h1>공유 링크</h1><p class="muted small">발행 시각 최신순 · 제목은 나에게만 보입니다.</p></div>${link('새 링크 발행','L01','normal',true)}</div>`;
 if(mode==='loading')return heading+notice('공유 링크 목록을 불러오는 중입니다.');if(mode==='error')return heading+err('공유 링크 목록을 불러오지 못했습니다.')+btn('목록 다시 불러오기','reload',true);
 if(mode==='empty'||!links.length)return heading+empty('발행한 링크가 없습니다.','공개 Catch가 없어도 링크를 발행할 수 있습니다.');
 return heading+`${mode==='stopUnknown'?notice('중단 여부를 확인하지 못했습니다.','완료나 실패로 단정하지 않습니다. 먼저 상태를 확인해 주세요.')+btn('상태 다시 확인','stop-check',true):mode==='stopError'?err('링크를 중단하지 못했습니다.')+btn('상태 다시 확인','stop-check'):mode==='stopping'?notice('중단을 요청하고 있습니다.'):''}<div class="list">${[...links].sort((a,b)=>Date.parse(b.issued)-Date.parse(a.issued)).map(l=>`<article class="list-row"><div><h2>${esc(l.title)}</h2>${badges(l.status==='stopped'?'중단됨':valid(l)?'유효':'만료됨',l.password?'비밀번호 설정됨':'비밀번호 없음')}<code class="link-url">${esc(mockURL(l))}</code><p class="small">발행 ${time(l.issued)}<br>만료 ${time(l.expires)}</p></div><div class="actions">${valid(l)?`${btn('URL 복사','copy',false,false,`data-id="${l.id}"`)}${btn('수신자 화면 열기','open-recipient',false,false,`data-id="${l.id}"`)}${btn('링크 중단','stop-link',false,['stopUnknown','stopping'].includes(mode),`data-id="${l.id}"`)}`:btn('열람 상태 확인','open-recipient',false,false,`data-id="${l.id}"`)}</div></article>`).join('')}</div>`}
function recipientGate(){const l=activeLink();const override=ui.recipientOverride;
 if(['denied','stopped','expired','blocked'].includes(override)||l&&!valid(l))return 'blocked';
 if(override==='password'||l?.password&&!data.passwordOK.has(l.id))return 'password';
 return 'ok';
}
function blockedLink(){return `<div class="narrow">${notice('이 링크는 열람할 수 없습니다.')}</div>`}
function passwordPage(){if(recipientGate()==='blocked')return blockedLink();return `<div class="narrow"><h1>비밀번호가 필요한 링크입니다.</h1><p>전달받은 비밀번호를 입력하세요.</p><form id="password-form" class="stack"><label><span>비밀번호</span><input name="recipientPassword" type="password" autocomplete="off" ${mode==='loading'?'disabled':''}></label>${mode==='wrong'?err('비밀번호가 맞지 않습니다.'):mode==='error'?err('비밀번호 확인을 완료하지 못했습니다. 비밀번호가 틀렸다는 뜻은 아닙니다.'):''}<div id="password-error" aria-live="polite"></div><div class="actions">${btn(mode==='loading'?'확인하는 중…':'열람하기','check-password',true,mode==='loading')}</div></form></div>`}
function recipientList(){const gate=recipientGate();if(gate==='blocked')return blockedLink();if(gate==='password')return passwordPage();if(mode==='error')return '<h1>공개 자료</h1>'+err('자료를 불러오지 못했습니다.')+btn('다시 불러오기','reload',true);
 const catches=mode==='empty'?[]:publicCatches();return `<h1>공개 자료</h1><div class="box">${profileCard()}</div><h2>공개 GitHub 자산</h2>${catches.length?`<div class="list">${catches.map(c=>catchRow(c,true)).join('')}</div>`:empty('현재 열람할 수 있는 공개 GitHub 자산이 없습니다.')}`}
function recipientDetail(){const gate=recipientGate();if(gate==='blocked')return blockedLink();if(gate==='password')return passwordPage();const b=back('공개 자료 목록으로','V02','normal');if(mode==='error')return b+err('자료를 불러오지 못했습니다.')+btn('다시 불러오기','reload',true);
 let c=data.catches.find(c=>c.id===ui.recipientCatch)||data.catches[0];if(mode==='noDraft')c={...data.catches[1],draft:null,visibility:'public',confirmed:true,mismatch:false,protected:false};
 if(['hidden','missing','protected'].includes(mode)||c.visibility!=='public'||c.protected||c.mismatch)return b+notice('현재 열람할 수 없는 자료입니다.');
 return `${b}<h1>${esc(c.title)}</h1><p class="small muted">${esc(data.profile.name)} · GitHub 기록 기반</p>${mode==='sourceError'?err('근거 원문에 접근하지 못했습니다. 현재 허용된 자료를 확인해 주세요.'):''}<div class="two-col"><div>${factDraft(c,true)}</div><div>${evidence(c)}</div></div>`}
function openProfile(){if(screen?.id!=='W02-P')ui.profileReturn=screen?.id||'H-01';showDialog('내 프로필',`<p>${esc(data.profile.name)}</p>`,`${btn('프로필 보기','profile-view',true)}${btn('프로필 수정','profile-edit')}${btn('GitHub 연결 상태','profile-github')}${btn('로그아웃','logout')}${btn('닫기','close')}`)}

document.addEventListener('change',e=>{
 if(e.target.id==='state-picker'){stateTo(e.target.value);return}
 if(e.target.id==='mobile-screen'){nav(e.target.value);return}
 if(e.target.name==='repo'){ui.selectedRepo=e.target.value;ui.states['A-01']='selected';ui.lastFixture='A-01:selected';history.replaceState(null,'',route('A-01','selected'));mode='selected';render();return}
 if(e.target.id==='use-password'){captureLinkForm();ui.usePassword=e.target.checked;render()}
});
function captureLinkForm(){const form=$('#link-form');if(form){ui.linkTitle=form.elements.title.value;ui.linkPassword=form.elements.password?.value||''}}
document.addEventListener('input',e=>{if(e.target.closest('#link-form'))captureLinkForm();if(e.target.closest('#profile-form'))ui.profileDraft=Object.fromEntries(new FormData($('#profile-form')))});
document.addEventListener('submit',e=>{e.preventDefault();if(e.target.id==='link-form')action('issue');if(e.target.id==='profile-form')action('profile-save');if(e.target.id==='password-form')action('check-password')});
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-action]');if(b&&!b.disabled){e.preventDefault();action(b.dataset.action,b);return}
 const a=e.target.closest('a[href^="#"]');
 if(a&&!e.metaKey&&!e.ctrlKey&&!e.shiftKey&&!e.altKey){
  const [id,q]=a.getAttribute('href').slice(1).split('?');
  if(id==='index'||byId[id]){e.preventDefault();if(id==='W03'&&['A-01','A-02','A-03'].includes(screen?.id))ui.tab='github';nav(id,new URLSearchParams(q).get('state')||undefined)}
 }
});
$('#dialog').addEventListener('cancel',()=>{if(dialogReturn?.isConnected)dialogReturn.focus()});
window.addEventListener('hashchange',()=>{if(location.hash==='#W03'&&['A-01','A-02','A-03'].includes(screen?.id))ui.tab='github';closeDialog();render();window.scrollTo(0,0)});
function action(a,el){const c=currentCatch();
 switch(a){
 case 'restart':initial();ui.guide=true;nav('W01','normal');break;
 case 'reset':initial();history.replaceState(null,'','#index');render();toast('예시를 초기화했습니다.');break;
 case 'login':data.logged=true;nav('W02','normal');break;
 case 'logout':closeDialog();data.logged=false;nav('W01','normal');break;
 case 'profile-reload':nav('W01-R','saved');break;
 case 'profile-save':{
  if(mode==='error'){toast('저장 실패 예시입니다. 입력과 현재 프로필을 유지합니다.');return}
  const form=$('#profile-form');if(!form)return;data.profile=Object.fromEntries(new FormData(form));ui.profileDraft=null;data.logged=true;nav(mode==='edit'?ui.profileReturn:'H-01',mode==='edit'?undefined:data.linked?'linked':'unlinked');break;
 }
 case 'profile-cancel':ui.profileDraft=null;nav(ui.profileReturn);break;
 case 'profile':openProfile();break;
 case 'profile-view':closeDialog();nav('W02-P','normal');break;
 case 'profile-edit':closeDialog();nav('W02','edit');break;
 case 'profile-github':closeDialog();nav('W02-G',data.linked?'connected':'normal');break;
 case 'close':closeDialog();break;
 case 'connect':data.linked=true;data.logged=true;ui.tab='github';nav('W03','normal');break;
 case 'github-tab':ui.tab='github';nav('W03','normal');break;
 case 'tab-catch':ui.tab='catch';render();break;
 case 'tab-github':ui.tab='github';render();break;
 case 'request':if(!ui.selectedRepo)return;data.repo=ui.selectedRepo;data.requested=true;data.analysis='accepted';nav('A-01','accepted');break;
 case 'request-check':toast('조회만 하는 예시입니다. 접수 불명 상태를 유지하며 새 요청을 보내지 않습니다.');break;
 case 'status-check':toast('상태 조회 예시입니다. 새 분석은 시작하지 않습니다. 다른 응답은 상단 상태 선택에서 비교하세요.');break;
 case 'demo-complete':data.requested=true;data.analysis='complete';nav('A-02','complete');break;
 case 'analysis-results':ui.resultReturn='A-02';data.analysis=mode;nav('W03-R',mode==='partial'?'partial':mode==='draftFail'?'noDraft':'normal');break;
 case 'partial-results':ui.resultReturn='A-03';nav('W03-R','partial');break;
 case 'history-results':ui.resultReturn='W03';nav('W03-R','normal');break;
 case 'open-catch':ui.currentCatch=el.dataset.id;ui.detailReturn=screen.id;nav('W04','normal');break;
 case 'confirm':if(mode==='saveError'){toast('확인 저장 실패 예시입니다. 확인·공개 상태를 유지합니다.');return}c.confirmed=true;nav('W05','normal');break;
 case 'choose-public':nav('W05','normal');break;
 case 'keep-private':c.visibility='private';nav('W04','normal');break;
 case 'publish':
  if(mode==='error'){toast('공개 저장 실패 예시입니다. Catch는 미공개 상태를 유지합니다.');return}
  if(!c.confirmed||c.mismatch||c.protected){toast('근거·기여 확인과 공개 조건을 먼저 확인해 주세요.');return}
  if(data.hasIssued&&!data.issuedIds.has(c.id)){nav('W05','afterLink');return}
  c.visibility='public';nav('W05','public');break;
 case 'hide':showDialog('이 Catch를 숨길까요?',`<p>${esc(c.title)}</p><p>기존 공유 링크에서도 다음 이동·새로고침부터 보이지 않습니다. 다른 공개 자산과 링크 자체는 유지됩니다.</p>`,btn('취소','close')+btn('숨기기','confirm-hide',true));break;
 case 'confirm-hide':c.visibility='hidden';closeDialog();nav('W04','normal');toast('숨김 예시가 반영되었습니다. 기존 링크에서 다시 확인할 수 있습니다.');break;
 case 'mismatch':showDialog('불일치 표시',`<p>이 Catch에 기록과 맞지 않는 내용이 있음을 표시합니다. 설명을 수정하거나 새로 생성하지 않습니다.</p>${c.visibility==='public'?'<p>이 Catch를 숨겨 기존 링크에서도 열람되지 않도록 합니다.</p>':'<p>이 Catch는 미공개 상태를 유지합니다.</p>'}`,btn('취소','close')+btn(c.visibility==='public'?'불일치 표시하고 숨기기':'불일치 표시하고 미공개 유지','confirm-mismatch',true));break;
 case 'confirm-mismatch':c.mismatch=true;c.visibility=c.visibility==='public'?'hidden':'private';closeDialog();nav('W04','normal');break;
 case 'evidence':{const ev=data.catches.find(x=>x.id===el.dataset.id);showDialog('합성 근거 원문',`<p class="small">실제 GitHub 자료가 아닌 화면 검토용 예시입니다.</p><h3>${esc(ev.evidence)}</h3><div class="evidence"><pre>${esc(ev.snippet)}</pre></div><p class="small muted">원본 URL 연결 위치만 보여 줍니다. 외부 페이지를 열지 않습니다.</p>`,btn('닫기','close',true));break}
 case 'show-password':{const inp=$('#link-form input[name=password]');inp.type=inp.type==='password'?'text':'password';el.textContent=inp.type==='password'?'비밀번호 보기':'비밀번호 숨기기';break}
 case 'issue':issue();break;
 case 'copy':copyURL(el?.dataset.id);break;
 case 'open-recipient':if(el?.dataset.id)data.currentLink=el.dataset.id;ui.recipientOverride=null;ui.states.V01='normal';ui.states.V02='normal';nav(activeLink()?.password&&valid(activeLink())?'V01':'V02','normal');break;
 case 'stop-link':data.currentLink=el.dataset.id;showDialog('이 링크를 중단할까요?',`<p><strong>${esc(activeLink()?.title)}</strong></p><code class="link-url">${esc(mockURL(activeLink()))}</code><p>이 URL로는 자료를 열람할 수 없습니다. 이미 열린 화면에는 다음 이동·새로고침부터 반영됩니다.</p><p>Catch를 삭제하거나 숨기는 행동은 아닙니다.</p>`,btn('취소','close')+btn('링크 중단','confirm-stop',true));break;
 case 'confirm-stop':if(activeLink())activeLink().status='stopped';closeDialog();nav('L03','normal');break;
 case 'stop-check':toast('중단 요청의 상태만 확인하는 예시입니다. 불명 상태에서 중단을 재전송하지 않습니다.');break;
 case 'check-password':checkPassword();break;
 case 'recipient-catch':ui.recipientCatch=el.dataset.id;nav('V03','normal');break;
 case 'reload':toast('조회 동작 예시입니다. 상태 선택에서 조회 성공·실패를 비교할 수 있습니다. 새 분석이나 발행은 하지 않습니다.');break;
 }
}
function issue(){captureLinkForm();const title=ui.linkTitle.trim();const validation=$('#link-validation');const fail=t=>{validation.innerHTML=err(t)};
 if(!title){fail('링크 제목을 입력해 주세요.');return}
 const links=[...data.links,...ui.linkFixtures];
 if(links.some(l=>valid(l)&&l.title.trim()===title)){fail('같은 제목의 유효한 링크가 이미 있습니다. 공유 링크 관리에서 확인해 주세요.');return}
 if(links.filter(valid).length>=5){fail('유효 링크는 최대 5개입니다. 사용하지 않는 링크를 중단해 주세요.');return}
 if(ui.usePassword&&!ui.linkPassword){fail('링크에 사용할 비밀번호를 입력해 주세요.');return}
 if(mode==='failed'){fail('링크를 발행하지 못했습니다. 성공 상태로 변경하지 않았습니다.');return}
 const l=makeLink(title,ui.usePassword?ui.linkPassword:'');data.links.push(l);data.currentLink=l.id;data.hasIssued=true;publicCatches().forEach(c=>data.issuedIds.add(c.id));ui.linkFixtures=[];ui.linkTitle='';ui.linkPassword='';ui.usePassword=false;nav('L02','normal');
}
async function copyURL(id){if(id)data.currentLink=id;const value=mockURL(activeLink());try{if(mode==='copyError')throw Error('example');await navigator.clipboard.writeText(value);toast('예시 URL을 복사했습니다. 실제 서비스 주소는 아닙니다.')}catch{toast('URL을 복사하지 못했습니다. 화면의 주소를 직접 선택해 복사해 주세요.')}}
function checkPassword(){if(recipientGate()==='blocked'){render();return}const form=$('#password-form');const input=form.elements.recipientPassword.value;const l=activeLink();const expected=l?.password||'검토1234';if(!input||input!==expected){$('#password-error').innerHTML=err(!input?'비밀번호를 입력해 주세요.':'비밀번호가 맞지 않습니다.');return}if(mode==='error'&&screen.id==='V01'){toast('확인 실패 예시입니다. 인증 완료로 바꾸지 않습니다.');return}if(l)data.passwordOK.add(l.id);ui.recipientOverride=null;nav('V02','normal')}
render();
