# 화면·데이터·근거 연결

## 후속 검토 입력 · v2.2

직접 출처는 이 작업 대화에서 사용자가 전달한 팀장 의견과 후속 확인이다. 자료 종류를 상단 탭으로 구성하고 공개 GitHub 자산 옆에 RAG 질의응답을 놓으며, 기존 사이드바 자리에 현재 화면의 AI 분석 결과를 표시한다. 기업 JD 프리셋 선택·직접 입력 버튼을 두고 JD가 없으면 일반 요약으로 표시한다. 사용자는 ‘lag’를 RAG 질의응답으로 확인했다.

- 탭: 포트폴리오·자기소개서·이력서는 준비 중, GitHub는 기존 공개 Catch, RAG는 질문과 근거 확인의 예시.
- JD: 백엔드·프론트엔드·데이터 엔지니어 프리셋 3개는 이번 화면 검토를 위한 임의 예시다. 실제 회사별 프리셋 목록·선택 권한·저장·수명은 미결이다.
- AI 결과: 현재 열람 가능한 GitHub 합성 자료의 사실·기여·근거만 사용한다. 실제 JD 매칭이나 생성형 AI 호출 결과가 아니다. 입력 JD와 질문은 페이지 메모리에만 있고 새로고침하면 초기화된다.
- 출시·계약: 사용자 의견을 검토 화면에 반영한 것이며 기존 10월 확정 범위·API·개인정보·RAG 데이터 계약의 공식 승인으로 취급하지 않는다. 준비 중 문서나 열람 금지 자료는 요약하지 않는다.

## 이전 검토 입력 · v2.1 (V02 배치는 v2.2로 대체)

출처는 이 작업 대화에서 사용자가 전달한 팀장 검토 의견이다. V02에 포트폴리오·자기소개서·이력서의 준비 중 안내와 추가 예정 사이드바, W03에 같은 세 자산의 준비 중 안내를 반영했다. 이는 기존 문서에 이미 구현된 기능을 확인한 결과가 아니라 새로 전달받은 화면 표현 요청이다. 실제 문서 처리·공개 범위·제공 시점은 이 수정에서 정하지 않는다. 기존 GitHub 자료의 열람과 수신자 접근 조건은 유지한다.

검토 기준일 2026-09-23. 현재 API 응답을 관찰한 명세가 아니라, 프로젝트 문서에서 요구하는 정보의 의미를 화면에 연결한 문서입니다. 화면 ID는 검토용이며 실제 URL/API 계약을 확정하지 않습니다.

## 기준 판본

- dev: `8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7`
- [PR #68](https://github.com/JminAILab/CatchU/pull/68): `89cc7b101e09e8d5086bc7fc1477d2bc1d5c7d29`, 수용 조건·실패 의미
- [PR #80](https://github.com/JminAILab/CatchU/pull/80): `e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718`, 도메인 재사용 정리
- [PR #79](https://github.com/JminAILab/CatchU/pull/79): `a9bbc50fa2b8b3dae36649f7b9dd18175ebd25c2`, 9/23 회원·자산 보완
- [PR #71](https://github.com/JminAILab/CatchU/pull/71): `eb645ab46c568f9df768e80bd4eed396c0a5c5c2`, 홈·분석 진행/실패 초안
- [PR #57](https://github.com/JminAILab/CatchU/pull/57): `12b30d8939f45ed078c6ea29cf7dc68fc0f92ed4`, 공유 링크 흐름

PR 번호는 설계 근거의 위치입니다. PR의 현재 개폐/병합 상태 또는 도메인 단계의 최종 승인으로 해석하지 않습니다. 승인 원문과 초안의 지위는 각 문서에서 확인합니다.

## 화면별 정보와 이동

| 화면 | 화면에 필요한 정보 | 다음 행동·경계 | 직접 근거 |
|---|---|---|---|
| W01, W01-R | 로그인 결과, 프로필 조회 성공 여부, 표시 이름 저장 여부 | 최초 입력 또는 홈; 조회 실패를 이름 없음으로 처리하지 않음 | [CatchU_회원자산_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/a9bbc50fa2b8b3dae36649f7b9dd18175ebd25c2/docs/ai-dlc-input-mvp/CatchU_%ED%9A%8C%EC%9B%90%EC%9E%90%EC%82%B0_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §5.1 |
| W02 | 표시 이름·소개·직무·기술 스택, 저장/조회 결과, 미저장 입력 | 최초 저장→홈, 수정→상세, 이탈 확인·로그아웃 실패 보존 | [CatchU_회원자산_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/a9bbc50fa2b8b3dae36649f7b9dd18175ebd25c2/docs/ai-dlc-input-mvp/CatchU_%ED%9A%8C%EC%9B%90%EC%9E%90%EC%82%B0_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §5.1 및 헤더 합의 |
| W02-P, W02-G | 현재 저장 프로필, GitHub 계정 연결/권한 상태 | 모달→보기→수정·연결; Google 로그인과 GitHub 연결 구분 | [CatchU_회원자산_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/a9bbc50fa2b8b3dae36649f7b9dd18175ebd25c2/docs/ai-dlc-input-mvp/CatchU_%ED%9A%8C%EC%9B%90%EC%9E%90%EC%82%B0_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md), [2026-09-16_meeting-decisions.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-16_meeting-decisions.md) |
| H-01 | 로그인 여부, GitHub 연결 여부, 접수된 repo 유무, 각 조회의 성공 여부 | 미연결→프로필, repo 미연결→자산 GitHub, 연결 후 구성은 미채택 비교안 | [CatchU_서비스홈_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/eb645ab46c568f9df768e80bd4eed396c0a5c5c2/docs/ai-dlc-input-mvp/CatchU_%EC%84%9C%EB%B9%84%EC%8A%A4%ED%99%88_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §5·§6.2·§7.2 |
| W03 | 본인 Catch 목록, 요청한 분석과 현재 상태·결과 참조 | Catch/분석 이력 탭, 이전 작업 다시 열기 | [CatchU_회원자산_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/a9bbc50fa2b8b3dae36649f7b9dd18175ebd25c2/docs/ai-dlc-input-mvp/CatchU_%ED%9A%8C%EC%9B%90%EC%9E%90%EC%82%B0_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §5.2, [2026-09-14_followup.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-14_followup.md) |
| A-01 | 선정 대상·선택 저장소, 대상별 동의 안내, 접수·거절·중복·불명 | 단일 동의·요청; 홈 직접 요청 금지; 불명은 조회 | [CatchU_저장소선택_분석동의_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/CatchU_%EC%A0%80%EC%9E%A5%EC%86%8C%EC%84%A0%ED%83%9D_%EB%B6%84%EC%84%9D%EB%8F%99%EC%9D%98_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md), [2026-09-14_followup.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-14_followup.md) |
| A-02 | 분석 참조, 현재 상태, 실패 범위, 등록/본인 열람 준비 | 결과 준비 확인 때만 결과 버튼; 0건·실패·초안 없음 구분 | [CatchU_분석진행_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/eb645ab46c568f9df768e80bd4eed396c0a5c5c2/docs/ai-dlc-input-mvp/CatchU_%EB%B6%84%EC%84%9D%EC%A7%84%ED%96%89_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §4·§5, [decisions.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/decisions.md) ADR-003 |
| A-03 | 실패/현재 상태·재요청 허용 응답·접수 결과 | 명시 요청, 접수 확인 창, 자동 이동·자동 재시도 없음 | [CatchU_분석실패_재요청_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/eb645ab46c568f9df768e80bd4eed396c0a5c5c2/docs/ai-dlc-input-mvp/CatchU_%EB%B6%84%EC%84%9D%EC%8B%A4%ED%8C%A8_%EC%9E%AC%EC%9A%94%EC%B2%AD_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §3~§5 |
| W03-R | 해당 분석의 결과 목록·출처, Catch별 확인/공개/초안 상태 | 1개도 목록→상세→같은 목록→진입 출처 | [CatchU_회원자산_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/a9bbc50fa2b8b3dae36649f7b9dd18175ebd25c2/docs/ai-dlc-input-mvp/CatchU_%ED%9A%8C%EC%9B%90%EC%9E%90%EC%82%B0_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §5.5 |
| W04 | 작업 사실·본인 기여·근거 참조/발췌·생성 설명·본인용 질문, 확인/불일치/공개/원본 상태 | 보기만으로 확인·공개하지 않음. 설명 직접 편집/답변 저장 없음 | [components.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/components.md), [requirements.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/requirements-analysis/requirements.md), [CatchU_회원자산_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/a9bbc50fa2b8b3dae36649f7b9dd18175ebd25c2/docs/ai-dlc-input-mvp/CatchU_%ED%9A%8C%EC%9B%90%EC%9E%90%EC%82%B0_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) |
| W05 | 확인 완료와 공개 저장 상태 | 지금 공개 또는 미공개 유지; 초안 실패와 공개 자격은 분리 | [decisions.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/domain-design/decisions.md), [requirements.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/requirements-analysis/requirements.md) FR2.2·FR4.1 |
| L01 | 현재 공개 프로필/Catch, 제목, 비밀번호 설정, 현재 유효 링크 | 0 Catch 허용, trim 제목 중복 우선, 최대 5개, 30일 | [CatchU_공유링크_정보_판단조건_초안.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%EC%A0%95%EB%B3%B4_%ED%8C%90%EB%8B%A8%EC%A1%B0%EA%B1%B4_%EC%B4%88%EC%95%88.md), [CatchU_공유링크_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/12b30d8939f45ed078c6ea29cf7dc68fc0f92ed4/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §4 |
| L02 | 발행 결과·URL·발행/만료 시각·비밀번호 설정 여부 | 복사 또는 수신자 화면, 관리로 복귀 | [CatchU_공유링크_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/12b30d8939f45ed078c6ea29cf7dc68fc0f92ed4/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §5 |
| L03 | 본인 링크 제목·상태·URL·발행/만료 | 중단 영향 확인, 중단 실패/불명 구분, Catch 상태 보존 | [CatchU_공유링크_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/12b30d8939f45ed078c6ea29cf7dc68fc0f92ed4/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §6 |
| V01 | 링크 유효 여부·비밀번호 필요/검증 결과 | 중단/만료/없는 링크 거부 우선, 로그인 요구 없음 | [CatchU_공유링크_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/12b30d8939f45ed078c6ea29cf7dc68fc0f92ed4/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §7, [2026-09-14_followup.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/2026-09-14_followup.md) |
| V02 | 현재 허용된 공개 프로필·Catch 목록 | 관리 제목·본인 질문·프로필 메뉴 없음; 0건≠조회 실패 | [CatchU_공유링크_정보_판단조건_초안.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%EC%A0%95%EB%B3%B4_%ED%8C%90%EB%8B%A8%EC%A1%B0%EA%B1%B4_%EC%B4%88%EC%95%88.md), [CatchU_공유링크_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/12b30d8939f45ed078c6ea29cf7dc68fc0f92ed4/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §7 |
| V03 | 현재 허용된 Catch·근거·설명 유무·원본 접근 | 같은 링크 목록 복귀; 숨김/없음 공통 거부; 원본 비공개와 일시 실패 구분 | [CatchU_공유링크_흐름_와이어프레임_초안.md](https://github.com/JminAILab/CatchU/blob/12b30d8939f45ed078c6ea29cf7dc68fc0f92ed4/docs/ai-dlc-input-mvp/CatchU_%EA%B3%B5%EC%9C%A0%EB%A7%81%ED%81%AC_%ED%9D%90%EB%A6%84_%EC%99%80%EC%9D%B4%EC%96%B4%ED%94%84%EB%A0%88%EC%9E%84_%EC%B4%88%EC%95%88.md) §7, [requirements.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/requirements-analysis/requirements.md) FR1.5·NFR1 |

## 우선 적용한 경계

[scope-document.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/scope-definition/scope-document.md) 및 [requirements.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/inception/requirements-analysis/requirements.md)를 첫 출시 범위 기준으로 사용했습니다. [CatchU_mvp_input.md](https://github.com/JminAILab/CatchU/blob/8866a682d1f5f755f94ac8a2e9d28f44ee27f7e7/docs/ai-dlc-input-mvp/CatchU_mvp_input.md)는 이전 시점 입력이며 대표 구성·G 기능을 포함한 과거 표현이 남아 있습니다. 이 입력만 읽어서 현재 MVP 화면을 늘리지 않았습니다.

PR #68/#80의 핵심은 근거·본인 기여와 등록 적합성입니다. 정상적으로 분석했지만 등록할 후보가 없으면 정상 0건, 실패 때문에 판단할 수 없으면 실패/확인 불가, 실패 영향과 독립된 적합 결과만 제공 가능, 설명 초안 생성 실패만으로 유효 Catch를 폐기하지 않는 경계를 반영했습니다. 후보가 있다는 사실과 서비스 등록·본인 열람 준비는 다릅니다.

[wireframes.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/rough-mockups/wireframes.md)와 [user-flow.md](https://github.com/JminAILab/CatchU/blob/e05ca63e4eb4bc34e41d4f9e27e88084d6b9a718/aidlc/spaces/default/intents/260914-catchu-october-mvp/ideation/rough-mockups/user-flow.md)는 화면 ID와 흐름을 대조하는 기준으로 사용했습니다. 최종 배치·문구·인터랙션 채택과 실제 서비스 검증은 별도입니다.

## 범위 밖 / 화면을 새로 만들지 않은 이유

피드·DM·기업/JD/검색·채용·알림 기능은 12월, 대표 구성·G 운영/선택 공유는 현행 첫 MVP 이후입니다. 일반 API 오류·접근 거부는 해당 화면 상태로 표현했습니다. 데이터가 정해지지 않은 관리자 대시보드, 점수/매칭률, 임의 분석 소요 시간, 알림 개수, 포트폴리오 편집기를 만들지 않았습니다.

## 미결 계약

[연결 조건 #23](https://github.com/JminAILab/CatchU/issues/23), [화면 위치/진입/복귀 #64](https://github.com/JminAILab/CatchU/issues/64), [프로필 #51](https://github.com/JminAILab/CatchU/issues/51), [헤더 #55](https://github.com/JminAILab/CatchU/issues/55), [홈 #22](https://github.com/JminAILab/CatchU/issues/22)의 연결 질문을 유지합니다. 이 파일에서 새로운 서버 상태값·재요청 허용 시간·본문 버전 규칙을 확정하지 않습니다.

## 출처·데이터의 한계

팀장님 공유 파일 4개는 전문 열람했습니다. 저장소 문서는 전문/관련 절/목록 확인을 [읽기 기록](reading-ledger.md)에서 구분합니다. 전 파일 전문 정독 완료를 주장하지 않습니다. 과거 실험 원자료와 비밀값은 화면 자료에 포함하지 않았습니다. GitHub 원문 링크는 팀원의 저장소 접근 권한이 있어야 열 수 있습니다.
